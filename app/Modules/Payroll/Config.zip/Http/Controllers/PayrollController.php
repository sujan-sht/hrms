<?php

namespace App\Modules\Payroll\Http\Controllers;

use Carbon\Carbon;
use App\Traits\LogTrait;
use Illuminate\Http\Request;
use PhpParser\Node\Stmt\Foreach_;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use App\Modules\Unit\Entities\Unit;
use App\Modules\Branch\Entities\Branch;
use App\Modules\Payroll\Entities\Payroll;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use App\Modules\Employee\Entities\Employee;
use App\Modules\Admin\Entities\DateConverter;
use App\Modules\Payroll\Entities\IncomeSetup;
use App\Modules\Payroll\Entities\EmployeeSetup;
use App\Modules\Payroll\Entities\PayrollIncome;
use App\Modules\Payroll\Entities\DeductionSetup;
use App\Modules\Payroll\Entities\PayrollEmployee;
use App\Modules\Payroll\Entities\GrossSalarySetup;
use App\Modules\Payroll\Entities\PayrollDeduction;
use App\Modules\Setting\Entities\UnitSetupSetting;
use App\Modules\Advance\Entities\AdvanceSettlement;
use App\Modules\Branch\Repositories\BranchInterface;
use App\Modules\Setting\Entities\BranchSetupSetting;
use App\Modules\Payroll\Http\Requests\PayrollRequest;
use App\Modules\Advance\Repositories\AdvanceInterface;
use App\Modules\Payroll\Repositories\PayrollInterface;
use App\Modules\Setting\Repositories\SettingInterface;
use App\Modules\Dropdown\Repositories\DropdownInterface;
use App\Modules\Employee\Repositories\EmployeeInterface;
use App\Modules\Payroll\Entities\PayrollTaxExcludeValue;
use App\Modules\Branch\Http\Controllers\BranchController;
use App\Modules\FiscalYearSetup\Entities\FiscalYearSetup;
use App\Modules\Setting\Entities\GrossSalarySetupSetting;
use App\Modules\Setting\Repositories\DepartmentInterface;
use App\Modules\Advance\Entities\AdvanceSettlementPayment;
use App\Modules\Payroll\Repositories\HoldPaymentInterface;
use App\Modules\Payroll\Repositories\IncomeSetupInterface;
use App\Modules\BulkUpload\Service\Import\PayrollDataImport;
use App\Modules\Payroll\Entities\IncomeReferenceSetupDetail;
use App\Modules\Setting\Entities\PayrollCalenderTypeSetting;
use App\Modules\Payroll\Repositories\DeductionSetupInterface;
use App\Modules\Attendance\Entities\AttendanceOrganizationLock;
use App\Modules\Organization\Repositories\OrganizationInterface;
use App\Modules\FiscalYearSetup\Repositories\FiscalYearSetupInterface;
use App\Modules\Advance\Repositories\AdvanceSettlementPaymentInterface;
use App\Modules\Leave\Entities\LeaveType;

class PayrollController extends Controller
{
    use LogTrait;
    private $payrollObj;
    private $organizationObj;
    private $branchObj;
    private $employeeObj;
    private $incomeSetupObj;
    private $deductionSetupObj;
    private $settingObj;
    private $fiscalYearObj;
    private $dropdown;
    private $holdPaymentObj;
    private $advanceSettlementPayment;
    private $advanceObj;
    private $department;


    /**
     *
     */
    public function __construct(
        PayrollInterface $payrollObj,
        OrganizationInterface $organizationObj,
        BranchInterface $branchObj,
        EmployeeInterface $employeeObj,
        IncomeSetupInterface $incomeSetupObj,
        DeductionSetupInterface $deductionSetupObj,
        SettingInterface $settingObj,
        FiscalYearSetupInterface $fiscalYearObj,
        DropdownInterface $dropdown,
        HoldPaymentInterface $holdPaymentObj,
        AdvanceSettlementPaymentInterface $advanceSettlementPayment,
        AdvanceInterface $advanceObj,
        DepartmentInterface $department
    ) {
        $this->payrollObj = $payrollObj;
        $this->organizationObj = $organizationObj;
        $this->branchObj = $branchObj;
        $this->employeeObj = $employeeObj;
        $this->incomeSetupObj = $incomeSetupObj;
        $this->deductionSetupObj = $deductionSetupObj;
        $this->settingObj = $settingObj;
        $this->fiscalYearObj = $fiscalYearObj;
        $this->dropdown = $dropdown;
        $this->holdPaymentObj = $holdPaymentObj;
        $this->advanceSettlementPayment = $advanceSettlementPayment;
        $this->advanceObj = $advanceObj;
        $this->department = $department;
    }

    /**
     *
     */
    public function index(Request $request)
    {
        $filter = $request->all();

        $data['payrollModels'] = $this->payrollObj->findAll(20, $filter);
        $data['organizationList'] = $this->organizationObj->getList();
        $data['employeeList'] = $this->employeeObj->getList();

        $yearArray = [];
        $firstYear = 2022;
        $lastYear = (int) date('Y');
        $dateConverter = new DateConverter();
        for ($i = $firstYear; $i <= $lastYear; $i++) {
            $yearArray[$i] = $i;
        }
        $data['yearList'] = $yearArray;
        $data['nepaliYearList'] = $dateConverter->getNepYears();
        $data['monthList'] = $dateConverter->getEngMonths();
        $data['nepaliMonthList'] = $dateConverter->getNepMonths();
        $data['branchStatus'] = BranchSetupSetting::first()->branch_type == '1' ? true : false;
        $data['unitStatus'] = UnitSetupSetting::first()->unit_type == '1' ? true : false;
        $data['branches'] = Branch::get();
        $data['units'] = Unit::where('status', '1')->get();
        return view('payroll::payroll.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     * @return Response
     */
    public function create()
    {
        $data['isEdit'] = false;
        $data['organizationList'] = $this->organizationObj->getList();
        $data['employeeList'] = $this->employeeObj->getList();

        $yearArray = [];
        $firstYear = 2022;
        $lastYear = (int) date('Y');
        $dateConverter = new DateConverter();
        for ($i = $firstYear; $i <= $lastYear; $i++) {
            $yearArray[$i] = $i;
        }
        // $data['calendarTypeList'] = $dateConverter->getCalendarTypes();
        $data['calendarTypeList'] = [
            'eng' => 'English'
        ];
        $data['nepcalendarTypeList'] = [
            'nep' => 'Nepali'
        ];
        $data['yearList'] = $dateConverter->getEngYears();
        $data['nepaliYearList'] = $dateConverter->getNepYears();
        $data['monthList'] = $dateConverter->getEngMonths();
        $data['nepaliMonthList'] = $dateConverter->getNepMonths();
        $data['branches'] = Branch::get();
        $data['units'] = Unit::where('status', '1')->get();
        $data['branchStatus'] = BranchSetupSetting::first()->branch_type == '1' ? true : false;
        $data['unitStatus'] = UnitSetupSetting::first()->unit_type == '1' ? true : false;
        return view('payroll::payroll.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function store(Request $request)
    {
        $isBranchSelected = $request->branch_id;
        $selectedUnitId = $request->unit_id;
        if ($isBranchSelected && count($isBranchSelected) > 0) {
            $generatePayrollBranchUnitValue = [];
            $remainingBranchId = [];
            if ($selectedUnitId && count($selectedUnitId) > 0) {
                $allSelectedUnit = Unit::whereIn('id', $selectedUnitId)->get();
                foreach ($allSelectedUnit as $unit) {
                    $generatePayrollBranchUnitValue[] = [
                        'branch_id' => $unit->branch_id,
                        'unit_id' => $unit->id
                    ];
                }
            }
            $remainingBranchId = collect($isBranchSelected)->diff(collect($generatePayrollBranchUnitValue)->pluck('branch_id')->unique());
            if ($remainingBranchId && count($remainingBranchId) > 0) {
                foreach ($remainingBranchId as $id) {
                    $generatePayrollBranchUnitValue[] = [
                        'branch_id' => $id,
                        'unit_id' => null
                    ];
                }
            }
            // try {
                foreach ($generatePayrollBranchUnitValue as $generatedData) {
                    $request['branch_id'] = $generatedData['branch_id'] ?? null;
                    $request['unit_id'] = $generatedData['unit_id'] ?? null;
                    $this->multiplePayrollCreate($request);
                }

                DB::commit();
                toastr()->success('Data Created Successfully');
                return redirect(route('payroll.index'));
            // } catch (\Throwable $th) {
            //     DB::rollBack();
            //     toastr()->error('Something Went Wrong !!');
            //     return redirect(route('payroll.index'));
            // }
        } else {
            $this->singlePayrollCreate($request);
        }


        return redirect(route('payroll.index'));
    }

    public function multiplePayrollCreate($request)
    {
        // dump($request->all(),'Sumitr');
        $inputData = $request->all();
        $branchId = $request->branch_id ?? null;
        $unitId = $request->unit_id ?? null;
        $branchFetch = Branch::where('id', $branchId)->first();
        $unitFetch = Unit::where('id', $unitId)->first();
        // dd('Payroll Store',$inputData);
        $inputData['calendar_type'] = $inputData['calendar_type'] ?? $inputData['eng_calendar_type'];
        if ($inputData['calendar_type'] == 'nep') {
            $inputData = [
                'organization_id' => $inputData['organization_id'],
                'calendar_type' => $inputData['calendar_type'],
                'year' => $inputData['year'],
                'month' => $inputData['month'],
                'branch_id' => $branchId,
                'unit_id' => $unitId
            ];
            $payrollModel = Payroll::where('organization_id', $request->organization_id)->where('year', $request->year)->where('month', $request->month)->where('branch_id', $branchId)->where('unit_id', $unitId)->get();
        } else {
            $inputData = [
                'organization_id' => $inputData['organization_id'],
                'calendar_type' => $inputData['eng_calendar_type'],
                'year' => $inputData['eng_year'],
                'month' => $inputData['eng_month'],
                'branch_id' => $branchId,
                'unit_id' => $unitId
            ];
            $payrollModel = Payroll::where('organization_id', $request->organization_id)->where('year', $request->eng_year)->where('month', $request->eng_month)->where('branch_id', $branchId)->where('unit_id', $unitId)->get();
        }
        $inputData['created_by'] = auth()->user()->id;
        $inputData['created_by_modal'] = get_class(auth()->user());
        $inputData['branch_id'] = $request->branch_id ?? null;
        $inputData['unit_id'] = $request->unit_id ?? null;
        DB::beginTransaction();
        if (count($payrollModel) > 0) {
            toastr()->warning('Payroll Already Exists');
        } else {
            $status = $this->payrollObj->create($inputData);
            if (!$status['status']) {
                $status['payrollModel']->delete();
                $message = $branchFetch->name . "," . @$unitFetch->title;
                toastr()->error("No employee found. Payroll can't be created for {{$message}}.");
            }
            DB::commit();
        }
    }

    public function singlePayrollCreate($request)
    {
        $inputData = $request->all();
        $branchId = $request->branch_id ?? null;
        $unitId = $request->unit_id ?? null;
        // dd('Payroll Store',$inputData);
        $inputData['calendar_type'] = $inputData['calendar_type'] ?? $inputData['eng_calendar_type'];
        if ($inputData['calendar_type'] == 'nep') {
            $inputData = [
                'organization_id' => $inputData['organization_id'],
                'calendar_type' => $inputData['calendar_type'],
                'year' => $inputData['year'],
                'month' => $inputData['month'],
                'branch_id' => $branchId,
                'unit_id' => $unitId
            ];
            $payrollModel = Payroll::where('organization_id', $request->organization_id)->where('year', $request->year)->where('month', $request->month)->where('branch_id', $branchId)->where('unit_id', $unitId)->get();
        } else {
            $inputData = [
                'organization_id' => $inputData['organization_id'],
                'calendar_type' => $inputData['eng_calendar_type'],
                'year' => $inputData['eng_year'],
                'month' => $inputData['eng_month'],
                'branch_id' => $branchId,
                'unit_id' => $unitId
            ];
            $payrollModel = Payroll::where('organization_id', $request->organization_id)->where('year', $request->eng_year)->where('month', $request->eng_month)->where('branch_id', $branchId)->where('unit_id', $unitId)->get();
        }
        $inputData['created_by'] = auth()->user()->id;
        $inputData['created_by_modal'] = get_class(auth()->user());
        $inputData['branch_id'] = $request->branch_id ?? null;
        $inputData['unit_id'] = $request->unit_id ?? null;
        DB::beginTransaction();
        try {
            if (count($payrollModel) > 0) {
                toastr()->warning('Payroll Already Exists');
            } else {
                $status = $this->payrollObj->create($inputData);
                if (!$status['status']) {
                    $status['payrollModel']->delete();
                    toastr()->error("No employee found. Payroll can't be created.");
                    return redirect()->back();
                }
                $latestInsertedId = Payroll::orderBy('id', 'DESC')->first();
                $logData = [
                    'title' => 'New payroll created',
                    'action_id' => $latestInsertedId->id,
                    'action_model' => get_class($latestInsertedId),
                    'route' => route('payroll.view', $latestInsertedId->id)
                ];
                $this->setActivityLog($logData);
                toastr()->success('Data Created Successfully');
                DB::commit();
            }
        } catch (\Throwable $e) {
            throw $e;
            toastr()->error('Something Went Wrong !!!');
        }
    }

    public function lockStatus(Request $request)
    {
        try {
            $inputData = json_decode($request->dataValue);
            $finalizeData['calendar_type'] = $inputData->calendar_type ?? $inputData->eng_calendar_type;
            $finalizeData = [];
            if ($inputData->calendar_type == 'nep') {
                $finalizeData = [
                    'organization_id' => $inputData->organization_id,
                    'calendar_type' => $inputData->calendar_type,
                    'year' => $inputData->year,
                    'month' => $inputData->month,
                ];
            } else {
                $finalizeData = [
                    'organization_id' => $inputData->organization_id,
                    'calendar_type' => $inputData->eng_calendar_type,
                    'year' => $inputData->eng_year,
                    'month' => $inputData->eng_month,
                ];
            }
            $lockStaus = false;
            $lockStatus = $this->checkStatus($finalizeData);
            $data = [
                'error' => false,
                'data' => $lockStatus,
                'msg' => 'Success'
            ];
        } catch (\Throwable $th) {
            $data = [
                'status' => true,
                'data' => false,
                'msg' => 'Something Went Wrong !!'
            ];
        }
        return response()->json($data, 200);
    }

    /**
     * Show the specified resource.
     * @return Response
     */
    public function show($id)
    {
        $payrollModel = $this->payrollObj->findOne($id);
        $attendanceLockStatus = false;
        $attendanceLockStatus = $this->checkAttendanceLockStatus($payrollModel);
        // $payrollModel = $payrollModel::whereHas('payrollEmployees',function($query){
        //     $query->whereHas('incomes',function($q){
        //         $q->whereHas('incomeSetup',function($iq){
        //             $iq->orderBy('order','ASC');
        //         });
        //     });
        // })->get();

        // $payrollModel = $payrollModel::with('payrollEmployees.incomes.incomeSetup')->get();
        // foreach ($payrollModel as $key => $value) {
        //     $pE= $value->payrollEmployees;
        //     foreach($pE as $p){
        //         if(!is_null($p->income)){
        //             $incomes = $p->income->collect()->orderBy('income_setup_id', 'DESC');
        //         }else{
        //             $incomes = [];
        //         }
        //     }
        // }
        // $payrollModel = $payrollModel::with(['payrollEmployees.incomes.incomeSetup' => function($query) {
        //     $query->orderBy('order','ASC');
        // }])->get();

        // dd($payrollModel);
        if ($payrollModel->calendar_type == 'nep') {
            $date_type = 'nepali_date';
        } else {
            $date_type = 'date';
        }
        $payrollModel->payrollEmployees->map(function ($model) use ($payrollModel, $date_type) {
            $advanceSettleModels = AdvanceSettlementPayment::whereHas('advanceModel', function ($query) use ($model) {
                $query->where('employee_id', $model->employee_id)->where('approval_status', 3);
            })
                ->where($date_type, 'like', $payrollModel->year . '-' . sprintf("%02d", $payrollModel->month) . '-%')
                ->get();

            if (count($advanceSettleModels) > 0) {
                $advanceAmount = 0;
                foreach ($advanceSettleModels as $advanceSettleModel) {
                    $advanceAmount += $advanceSettleModel->amount;
                }
                $model->advanceAmount = $advanceAmount;
            }

            return $model;
        });

        $data['payrollModel'] = $payrollModel;
        $data['incomes'] = $payrollModel->getIncomes();
        $data['taxExcludeValues'] = $payrollModel->getTaxExcludeValues();
        $data['deductions'] = $payrollModel->getDeductions();
        // $data['incomes'] = $this->incomeSetupObj->getList();
        // $data['deductions'] = $this->deductionSetupObj->getList();
        // $data['deductions'] = $this->deductionSetupObj->getMonthlyDeductionList();
        $data['attendanceLockStatus'] = $attendanceLockStatus;
        if ($payrollModel->checkCompleted()) {
            return view('payroll::payroll.lock', $data);
        }

        return view('payroll::payroll.show', $data);
    }

    public function showResignedEmployee($id)
    {
        $payrollModel = $this->payrollObj->findOne($id);
        $attendanceLockStatus = false;
        $attendanceLockStatus = $this->checkAttendanceLockStatus($payrollModel);

        if ($payrollModel->calendar_type == 'nep') {
            $date_type = 'nepali_date';
        } else {
            $date_type = 'date';
        }
        $payrollModel->payrollEmployees->map(function ($model) use ($payrollModel, $date_type) {
            $advanceSettleModels = AdvanceSettlementPayment::whereHas('advanceModel', function ($query) use ($model) {
                $query->where('employee_id', $model->employee_id)->where('approval_status', 3);
            })
                ->where($date_type, 'like', $payrollModel->year . '-' . sprintf("%02d", $payrollModel->month) . '-%')
                ->get();

            if (count($advanceSettleModels) > 0) {
                $advanceAmount = 0;
                foreach ($advanceSettleModels as $advanceSettleModel) {
                    $advanceAmount += $advanceSettleModel->amount;
                }
                $model->advanceAmount = $advanceAmount;
            }

            return $model;
        });

        $data['payrollModel'] = $payrollModel;
        $data['incomes'] = $payrollModel->getIncomes();
        $data['taxExcludeValues'] = $payrollModel->getTaxExcludeValues();
        $data['deductions'] = $payrollModel->getDeductions();
        $data['attendanceLockStatus'] = $attendanceLockStatus;
        if ($payrollModel->checkCompleted()) {
            return view('payroll::payroll.lockresigned', $data);
        }

        return view('payroll::payroll.show', $data);
    }

    public function checkAttendanceLockStatus($data)
    {
        if (setting('attendance_lock') == 11) {
            $attendanceLockData = AttendanceOrganizationLock::where([
                ['organization_id', $data->organization_id],
                ['calender_type', $data->calendar_type],
                ['year', $data->year],
                ['month', $data->month],
                ['lock_type', '2']
            ])->first();
            if (@$attendanceLockData) {
                return true;
            }
            return false;
        } else {
            return true;
        }
    }

    public function checkStatus($data)
    {
        if (setting('attendance_lock') == 11) {
            $attendanceLockData = AttendanceOrganizationLock::where([
                ['organization_id', $data['organization_id']],
                ['calender_type', $data['calendar_type']],
                ['year', $data['year']],
                ['month', $data['month']],
                ['lock_type', '2']
            ])->first();
            if (@$attendanceLockData) {
                return true;
            }
            return false;
        } else {
            return true;
        }
    }
    /**
     * Show the form for editing the specified resource.
     * @return Response
     */
    public function edit($id)
    {
        // $data['isEdit'] = true;
        // $data['payrollModel'] = $this->payrollObj->findOne($id);
        // $data['organizationList'] = $this->organizationObj->getList();
        // $data['employeeList'] = $this->employeeObj->getList();

        // return view('payroll::payroll.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     * @param  Request $request
     * @return Response
     */
    public function update(PayrollRequest $request, $id)
    {
        // $data = $request->all();

        // try {
        //     $this->payrollObj->update($id, $data);

        //     toastr()->success('Data Updated Successfully');
        // } catch (\Throwable $e) {
        //     toastr()->error('Something Went Wrong !!!');
        // }

        // return redirect(route('payroll.index'));
    }

    /**
     * Remove the specified resource from storage.
     * @return Response
     */
    public function destroy($id)
    {
        try {
            $this->payrollObj->delete($id);
            $logData = [
                'title' => 'Payroll deleted',
                'action_id' => null,
                'action_model' => null,
                'route' => route('payroll.index')
            ];
            $this->setActivityLog($logData);
            toastr()->success('Data Deleted Successfully');
        } catch (\Throwable $e) {
            toastr()->error('Something Went Wrong !!!');
        }

        return redirect()->back();
    }

    /**
     *
     */
    public function draft(Request $request, $id)
    {
        $inputData = $request->all();
        $payrollModel = $this->payrollObj->findOne($id);
        try {
            # update payroll income for mannual entry
            if (isset($inputData['payroll_income']) && count($inputData['payroll_income']) > 0) {
                foreach ($inputData['payroll_income'] as $payrollIncomeId => $value) {
                    $payrollIncomeData['value'] = $inputData['payroll_income'][$payrollIncomeId];
                    $payrollIncomeModel = PayrollIncome::find($payrollIncomeId);

                    if ($inputData['status'] == 2 || (optional($payrollIncomeModel->incomeSetup)->short_name != 'SSF' && $payrollIncomeModel->incomeSetup->daily_basis_status == 10)) {
                        $payrollIncomeModel->update($payrollIncomeData);
                    }
                }
            }
            # update payroll deduction for mannual entry
            if (isset($inputData['payroll_deduction']) && count($inputData['payroll_deduction']) > 0) {
                foreach ($inputData['payroll_deduction'] as $payrollDeductionId => $value) {
                    $payrollDeductionData['value'] = $value;
                    $payrollDeductionModel = PayrollDeduction::find($payrollDeductionId);
                    if ($inputData['status'] == 2 || optional($payrollDeductionModel->deductionSetup)->method == 3) {
                        $payrollDeductionModel->update($payrollDeductionData);
                    }
                }
            }
            if (isset($inputData['payroll_tax_exclude_value']) && count($inputData['payroll_tax_exclude_value']) > 0) {
                foreach ($inputData['payroll_tax_exclude_value'] as $payrollTaxExcludevalueId => $value) {
                    $payrollTaxExcludeData['value'] = $value;
                    // dd($payrollTaxExcludeData);
                    $payrollTaxExcludeModel = PayrollTaxExcludeValue::find($payrollTaxExcludevalueId);
                    $payrollTaxExcludeModel->update($payrollTaxExcludeData);
                }
            }

            if (count($inputData['total_income']) > 0) {
                foreach ($inputData['total_income'] as $payrollEmployeeId => $value) {
                    $payrollEmployeeData['total_income'] = $value;
                    $payrollEmployeeData['marital_status'] = $inputData['marital_status'][$payrollEmployeeId];
                    $payrollEmployeeData['total_days'] = $inputData['total_days'][$payrollEmployeeId];
                    $payrollEmployeeData['total_working_days'] = $inputData['total_working_days'][$payrollEmployeeId];
                    $payrollEmployeeData['extra_working_days'] = $inputData['extra_working_days'][$payrollEmployeeId];
                    $payrollEmployeeData['unpaid_leave_days'] = $inputData['unpaid_leave_days'][$payrollEmployeeId];
                    $payrollEmployeeData['paid_leave_days'] = $inputData['paid_leave_days'][$payrollEmployeeId];
                    $payrollEmployeeData['overtime_pay'] = $inputData['overtime_pay'][$payrollEmployeeId];
                    $payrollEmployeeData['fine_penalty'] = $inputData['fine_penalty'][$payrollEmployeeId];
                    $payrollEmployeeData['total_deduction'] = $inputData['total_deduction'][$payrollEmployeeId];
                    $payrollEmployeeData['festival_bonus'] = $inputData['festival_bonus'][$payrollEmployeeId];
                    $payrollEmployeeData['leave_amount'] = $inputData['leave_amount'][$payrollEmployeeId];
                    // $payrollEmployeeData['monthly_total_deduction'] = $inputData['monthly_total_deduction'][$payrollEmployeeId];
                    $payrollEmployeeData['yearly_taxable_salary'] = $inputData['yearly_taxable_salary'][$payrollEmployeeId];
                    $payrollEmployeeData['sst'] = $inputData['sst'][$payrollEmployeeId];
                    // $payrollEmployeeData['sst'] = 0;
                    $payrollEmployeeData['tds'] = $inputData['tds'][$payrollEmployeeId];
                    // $payrollEmployeeData['extra_working_days_amount'] = $inputData['extra_working_days_amount'][$payrollEmployeeId];
                    $payrollEmployeeData['net_salary'] = $inputData['net_salary'][$payrollEmployeeId];
                    $payrollEmployeeData['single_women_tax_credit'] = $inputData['single_women_tax_credit'][$payrollEmployeeId];
                    $payrollEmployeeData['adjustment_status'] = $inputData['adjustment_status'][$payrollEmployeeId];
                    $payrollEmployeeData['adjustment'] = $inputData['adjustment'][$payrollEmployeeId];
                    $payrollEmployeeData['advance_amount'] = $inputData['advance_amount'][$payrollEmployeeId];
                    $payrollEmployeeData['payable_salary'] = $inputData['payable_salary'][$payrollEmployeeId];
                    $payrollEmployeeData['remarks'] = $inputData['remark'][$payrollEmployeeId];
                    $payrollEmployeeData['status'] = $inputData['status'];

                    $payrollEmployeeModel = PayrollEmployee::find($payrollEmployeeId);
                    $payrollEmployeeModel->update($payrollEmployeeData);
                    if ($inputData['status'] == 2) {
                        if ($payrollModel->calendar_type == 'nep') {
                            $date_type = 'nepali_date';
                        } else {
                            $date_type = 'date';
                        }
                        $advanceSettleModels = AdvanceSettlementPayment::whereHas('advanceModel', function ($query) use ($payrollEmployeeModel) {
                            $query->where('employee_id', $payrollEmployeeModel->employee_id)->where('approval_status', 3);
                        })
                            ->where($date_type, 'like', $payrollModel->year . '-' . sprintf("%02d", $payrollModel->month) . '-%')
                            ->get();

                        if (count($advanceSettleModels) > 0) {
                            foreach ($advanceSettleModels as $advanceSettleModel) {
                                $data['status'] = 11;
                                $this->advanceSettlementPayment->update($advanceSettleModel->id, $data);
                                $count = AdvanceSettlementPayment::where('advance_id', $advanceSettleModel->advance_id)->where('status', 10)->count();
                                if ($count == 0) {
                                    $advanceStatus['status'] = 3;
                                    $this->advanceObj->updateAdvanceStatus($advanceSettleModel->advance_id, $advanceStatus);
                                } else {
                                    $advanceStatus['status'] = 2;
                                    $this->advanceObj->updateAdvanceStatus($advanceSettleModel->advance_id, $advanceStatus);
                                }
                            }
                        }
                    }
                }
            }
            if ($inputData['status'] == 2) {
                $payrollModel->finalized_by = auth()->user()->id;
                $payrollModel->finalized_by_modal = get_class(auth()->user());
                $payrollModel->save();
            }
            $append = $inputData['status'] == '2' ? 'Finalized' : 'Draft';
            $logData = [
                'title' => 'Payroll ' . $append,
                'action_id' => $payrollModel->id,
                'action_model' => get_class($payrollModel),
                'route' => route('payroll.view', $payrollModel->id)
            ];
            $this->setActivityLog($logData);
            toastr()->success('Payroll updated Successfully');
        } catch (\Throwable $th) {
            throw $th;
            toastr()->error('Something Went Wrong !!!');
        }

        return redirect()->back();
    }


    public function viewEmployee(Request $request, $id)
    {
        $filter = $request->all();
        $filter['payroll_id'] = $id;
        $payrollModel = $this->payrollObj->findOne($id);
        $filter['organization_id'] = $payrollModel->organization_id;
        $data['payrollModel'] = $payrollModel;
        $data['employeeList'] = $this->employeeObj->employeeListWithFilter($filter);
        $data['payrollEmployeeModels'] = $this->payrollObj->findAllPayrollEmployee($limit = 50, $filter);
        $data['holdPayment'] = $this->holdPaymentObj->getHoldPaymentEmployeeWithStatus($payrollModel->year, $payrollModel->month, $payrollModel->organization_id);
        return view('payroll::payroll.view-employee', $data);
    }


    public function employeeHistory($id)
    {
        $payrollEmployee = $this->payrollObj->findPayrollEmployee($id);
        $payrollModel = $this->payrollObj->findOne($payrollEmployee->payroll_id);
        $data['deductions'] = $payrollModel->getDeductions();
        $data['incomes'] = $payrollModel->getIncomes();
        $data['payrollEmployee'] = $payrollEmployee;
        return view('payroll::payroll.employee-history', $data);
    }

    public function employeeSalarySlip($id)
    {
        $payrollEmployee = $this->payrollObj->findPayrollEmployee($id);
        $data['incomes'] = $this->incomeSetupObj->getList();
        $data['deductions'] = $this->deductionSetupObj->getMonthlyDeductionList();
        $data['payrollEmployee'] = $payrollEmployee;
        $data['setting'] = $this->settingObj->getData();
        $data['grossSalarySetup'] = GrossSalarySetupSetting::first();
        $data['incomeTypeValues'] = $this->getGrossTypeData($data['grossSalarySetup']->gross_salary_type, $payrollEmployee);
        return view('payroll::payroll.employee-salary-slip', $data);
    }

    public function getGrossTypeData($type, $payrollEmployee)
    {
        $data = [];
        switch ($type) {
            case '1':
                $data['field'] = 'employee_id';
                $searchId = $payrollEmployee->employee->employee_id ?? null;
                $data['incomeData'] = $this->getIncomeDetails($data, $searchId, $payrollEmployee);
                break;
            case '2':
                $data['field'] = 'level_id';
                $searchId = $payrollEmployee->employee->level_id ?? null;
                $data['incomeData'] = $this->getIncomeDetails($data, $searchId, $payrollEmployee);
                break;
            case '3':
                $data['field'] = 'designation_id';
                $searchId = $payrollEmployee->employee->designation_id ?? null;
                $data['incomeData'] = $this->getIncomeDetails($data, $searchId, $payrollEmployee);
                break;
            default:
                break;
        }
        return $data;
    }

    public function getIncomeDetails($data, $searchId, $payrollEmployee)
    {
        $incomeReferenceSetupDetails = IncomeReferenceSetupDetail::where($data['field'], $searchId)->get()->pluck('income_setup_id');
        if ($incomeReferenceSetupDetails) {
            $incomeSetup = IncomeSetup::where('organization_id', $payrollEmployee->employee->organization_id)->whereIn('id', $incomeReferenceSetupDetails)->orderBy('order', 'asc')->get()->pluck('title', 'id');
        }
        return $incomeSetup ?? null;
    }
    public function exportStaticData(Request $request)
    {
        $filter = $request->all();
        $payrollModel = $this->payrollObj->findOne($filter['payroll_id']);
        $styleArray = [
            'font' => [
                'bold' => true,
            ],
            'alignment' => [
                'horizontal' => \PhpOffice\PhpSpreadsheet\Style\Alignment::HORIZONTAL_LEFT,
            ],
            'borders' => [
                'top' => [
                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                ],
            ],
            'fill' => [
                'fillType' => \PhpOffice\PhpSpreadsheet\Style\Fill::FILL_SOLID,
                'startColor' => [
                    'rgb' => 'FFFF00',
                ],
            ],

        ];

        $objPHPExcel = new Spreadsheet();
        $worksheet = $objPHPExcel->getActiveSheet();

        $objPHPExcel->setActiveSheetIndex(0);

        $objPHPExcel->getActiveSheet()->SetCellValue('A1', 'S.N');
        $objPHPExcel->getActiveSheet()->SetCellValue('B1', 'Year');
        $objPHPExcel->getActiveSheet()->SetCellValue('C1', 'Month');
        $objPHPExcel->getActiveSheet()->SetCellValue('D1', 'Employee Id');
        $objPHPExcel->getActiveSheet()->SetCellValue('E1', 'Employee Name');
        $objPHPExcel->getActiveSheet()->SetCellValue('F1', 'Over Time Pay');
        $objPHPExcel->getActiveSheet()->SetCellValue('G1', 'Fine and Penalty');
        $objPHPExcel->getActiveSheet()->SetCellValue('H1', 'Festival Bonus');

        $num = 2;
        $incr = 0;

        foreach ($payrollModel->payrollEmployees as $key => $value) {
            // dd($value->fine_penalty);

            $objPHPExcel->getActiveSheet()->SetCellValue('A' . $num, ++$incr);
            $objPHPExcel->getActiveSheet()->SetCellValue('B' . $num, $payrollModel->year);
            $objPHPExcel->getActiveSheet()->SetCellValue('C' . $num, $payrollModel->month);
            $objPHPExcel->getActiveSheet()->SetCellValue('D' . $num, $value->employee_id);
            $objPHPExcel->getActiveSheet()->SetCellValue('E' . $num, optional($value->employee)->getFullName());
            $objPHPExcel->getActiveSheet()->SetCellValue('F' . $num, $value->overtime_pay ?? 0);
            $objPHPExcel->getActiveSheet()->SetCellValue('G' . $num, $value->fine_penalty ?? 0);
            $objPHPExcel->getActiveSheet()->SetCellValue('H' . $num, $value->festival_bonus ?? 0);

            $num++;
        }

        $writer = new Xlsx($objPHPExcel);
        $file = 'employee_payroll_data';
        $filename = $file . '.xlsx';
        header('Content-Type: application/vnd.ms-excel'); //mime type
        header('Content-Disposition: attachment;filename="' . $filename . '"'); //tell browser what's the file name
        header('Cache-Control: max-age=0'); //no cache

        $writer->save('php://output');
    }
    public function uploadPayrollStaticData(Request $request)
    {
        // dd($request);
        $files = $request->upload_payroll_static_data;
        // dd($files);
        $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReader("Xlsx");

        $reader->setReadDataOnly(true);

        $spreadsheet = $reader->load($files);
        \PhpOffice\PhpSpreadsheet\Cell\Cell::setValueBinder(new \PhpOffice\PhpSpreadsheet\Cell\AdvancedValueBinder());

        $sheetData = $spreadsheet->getActiveSheet()->toArray();
        array_shift($sheetData);

        $import_file = PayrollDataImport::import($sheetData);

        if ($import_file) {
            toastr()->success('Payroll Data  Imported Successfully');
        }

        return redirect()->back();
    }

    public function salaryTransfer($id)
    {
        $payrollModel = $this->payrollObj->findOne($id);
        $data['holdPayment'] = $this->holdPaymentObj->getHoldPaymentEmployee($payrollModel->year, $payrollModel->month, $payrollModel->organization_id);
        $data['payrollModel'] = $payrollModel;
        $data['setting'] = $this->settingObj->getData();
        return view('payroll::payroll.salary-transfer-letter', $data);
    }
    public function holdPayment($id)
    {
        $data['payrollModel'] = $payrollModel = $this->payrollObj->findOne($id);
        $data['holdPayments'] = $this->holdPaymentObj->getHoldPayment($payrollModel->year, $payrollModel->month, $payrollModel->organization_id);
        $data['employeeList'] = $this->holdPaymentObj->getHoldPaymentEmployeeNameList($payrollModel->year, $payrollModel->month, $payrollModel->organization_id);
        $data['statusList'] =  $status = $this->holdPaymentObj->getStatus();
        $data['employeeList'] = $this->holdPaymentObj->getHoldPaymentEmployeeNameList($payrollModel->year, $payrollModel->month, $payrollModel->organization_id);
        return view('payroll::payroll.hold-payment', $data);
    }
    public function logReport(Request $request)
    {
        $filter = $request->all();
        $yearArray = [];
        $data['tax'] = [];
        $firstYear = 2022;
        $lastYear = (int) date('Y');
        $dateConverter = new DateConverter();
        for ($i = $firstYear; $i <= $lastYear; $i++) {
            $yearArray[$i] = $i;
        }
        $data['fiscalYearList'] = $this->fiscalYearObj->find();
        $data['fiscalYear'] = $this->fiscalYearObj->findAll();
        $data['englishFiscalYearList'] = [];
        foreach ($data['fiscalYear'] as $key => $value) {
            $startFiscalDate = $value->start_date_english;
            $endFiscalDate = $value->end_date_english;
            $startFiscalYear = date('Y', strtotime($startFiscalDate));
            $endFiscalYear = date('y', strtotime($endFiscalDate));
            $fiscalYear = $startFiscalYear . '/' . $endFiscalYear;
            $data['englishFiscalYearList'][$fiscalYear] =  $fiscalYear;
        }
        $fiscalYear = FiscalYearSetup::currentFiscalYear();
        $data['yearList'] = $yearArray;
        $data['employeeList'] = $this->employeeObj->getList();
        $data['organizationList'] = $this->organizationObj->getList();
        $data['nepaliYearList'] = $dateConverter->getNepYears();
        $data['nepaliMonthList'] = $dateConverter->getNepMonths();
        if (isset($filter['organization_id'])) {
            if (isset($filter['year']) && $filter['year']) {
                $filter['year'] = $filter['year'];
                $startMonth = $fiscalYear->end_date;
                $startMonth = explode('-', $startMonth);
                $startMonth = (int) $startMonth[1];
                $data['months'] = $months =  [
                    4 => 'Shrawan',
                    5 =>  'Bhadra',
                    6 => 'Ashwin',
                    7 => 'Kartik',
                    8 => 'Mangsir',
                    9 => 'Poush',
                    10 => 'Magh',
                    11 => 'Falgun',
                    12 => 'Chaitra',
                    1 => 'Baisakh',
                    2 => 'Jestha',
                    3 => 'Ashad',
                ];
            } else {
                $filter['year'] = $filter['eng_year'];
                $startMonth = $fiscalYear->end_date_english;
                $startMonth = explode('-', $startMonth);
                $startMonth = (int) $startMonth[1];
                $data['months'] = $months =  [
                    7 => 'July',
                    8 => 'August',
                    9 => 'September',
                    10 => 'October',
                    11 => 'November',
                    12 => 'December',
                    1 => 'January',
                    2 => 'February',
                    3 => 'March',
                    4 => 'April',
                    5 =>  'May',
                    6 => 'June',
                ];
            }
            $explodeFiscalYear = explode('/', $filter['year']);
            $data['year'] =  $year = $explodeFiscalYear[0];
            $data['organizationModel'] = $this->organizationObj->findOne($filter['organization_id']);
            $data['employeeModel'] = $this->employeeObj->find($filter['employee_id']);
            $incomes = IncomeSetup::where('organization_id', $filter['organization_id'])->get();
            $data['lastMonthPayroll'] = PayrollEmployee::where('employee_id', $filter['employee_id'])->where('status', 2)->latest()->first();
            $data['incomeSetups'] = IncomeSetup::where('organization_id', $filter['organization_id'])->get()->map(function ($incomes) use ($months, $year, $filter, $startMonth) {
                foreach ($months as $key => $value) {
                    if ($key > $startMonth) {
                        $income = PayrollIncome::whereHas('payroll', function ($query) use ($key, $year, $filter) {
                            $query->where('year', $year)->where('month', $key);
                        })->whereHas('payrollEmployee', function ($q) use ($filter) {
                            $q->where('employee_id', $filter['employee_id'])->where('status', 2);
                        })->where('income_setup_id', $incomes->id)->first();
                        if ($income) {
                            $month[$value] = $income->value;
                        } else {
                            $month[$value] = 0;
                        }
                    } else {
                        $income = PayrollIncome::whereHas('payroll', function ($query) use ($key, $year, $filter) {
                            $query->where('year', $year + 1)->where('month', $key);
                        })->whereHas('payrollEmployee', function ($q) use ($filter) {
                            $q->where('employee_id', $filter['employee_id'])->where('status', 2);
                        })->where('income_setup_id', $incomes->id)->first();
                        if ($income) {
                            $month[$value] = $income->value;
                        } else {
                            $month[$value] = 0;
                        }
                    }
                }
                $incomes->income = $month;
                return $incomes;
            });
            $data['deductionSetups'] = DeductionSetup::where('organization_id', $filter['organization_id'])->where('monthly_deduction', 11)->get()->map(function ($deductions) use ($months, $year, $filter, $startMonth) {
                foreach ($months as $key => $value) {
                    if ($key > $startMonth) {
                        $deduction = PayrollDeduction::whereHas('payroll', function ($query) use ($key, $year, $filter) {
                            $query->where('year', $year)->where('month', $key);
                        })->whereHas('payrollEmployee', function ($q) use ($filter) {
                            $q->where('employee_id', $filter['employee_id'])->where('status', 2);
                        })->where('deduction_setup_id', $deductions->id)->first();
                        if ($deduction) {
                            $month[$value] = $deduction->value;
                        } else {
                            $month[$value] = 0;
                        }
                    } else {
                        $deduction = PayrollDeduction::whereHas('payroll', function ($query) use ($key, $year, $filter) {
                            $query->where('year', $year + 1)->where('month', $key);
                        })->whereHas('payrollEmployee', function ($q) use ($filter) {
                            $q->where('employee_id', $filter['employee_id'])->where('status', 2);
                        })->where('deduction_setup_id', $deductions->id)->first();
                        if ($deduction) {
                            $month[$value] = $deduction->value;
                        } else {
                            $month[$value] = 0;
                        }
                    }
                }
                $deductions->deduction = $month;
                return $deductions;
            });
            foreach ($months as $key => $value) {
                if ($key > $startMonth) {
                    $payrollEmployee = PayrollEmployee::whereHas('payroll', function ($query) use ($key, $year, $filter) {
                        $query->where('year', $year)->where('month', $key);
                    })->where('employee_id', $filter['employee_id'])->where('status', 2)->first();
                    if ($payrollEmployee) {
                        $data['tax']['sst'][$value] = $payrollEmployee->sst;
                        $data['tax']['tds'][$value] = $payrollEmployee->tds;
                    } else {
                        $data['tax']['sst'][$value] = 0;
                        $data['tax']['tds'][$value] = 0;
                    }
                } else {
                    $payrollEmployee = PayrollEmployee::whereHas('payroll', function ($query) use ($key, $year, $filter) {
                        $query->where('year', $year + 1)->where('month', $key);
                    })->where('employee_id', $filter['employee_id'])->first();
                    if ($payrollEmployee) {
                        $data['tax']['sst'][$value] = $payrollEmployee->sst;
                        $data['tax']['tds'][$value] = $payrollEmployee->tds;
                    } else {
                        $data['tax']['sst'][$value] = 0;
                        $data['tax']['tds'][$value] = 0;
                    }
                }
            }
            $data['taxDetail'] = $this->payrollObj->taxDetail($data['lastMonthPayroll']->yearly_taxable_salary, $data['employeeModel']);
            $data['payrollEmployeeModels'] =  PayrollEmployee::whereHas('payroll', function ($query) use ($year, $filter) {
                $query->where('year', $year)->where('month', '>', 3);
                $query->orWhere('year', $year + 1)->where('month', '<=', 3);
                $query->where('organization_id', $filter['organization_id']);
            })->where('employee_id', $filter['employee_id'])->get();

            // dd($data['payrollEmployeeModels']);
        }
        return view('payroll::payroll.log-report.report', $data);
    }

    public function ssfReport(Request $request)
    {
        $filter = $request->all();
        $data['organizationList'] = $this->organizationObj->getList();
        $data['branchList'] = $this->branchObj->getList();
        $data['employeePluck'] = $this->employeeObj->getList();
        $data['fiscalYearList'] = $this->fiscalYearObj->find();
        $data['fiscalYear'] = $this->fiscalYearObj->findAll();
        $data['englishFiscalYearList'] = [];
        foreach ($data['fiscalYear'] as $key => $value) {
            $startFiscalDate = $value->start_date_english;
            $endFiscalDate = $value->end_date_english;
            $startFiscalYear = date('Y', strtotime($startFiscalDate));
            $endFiscalYear = date('y', strtotime($endFiscalDate));
            $fiscalYear = $startFiscalYear . '/' . $endFiscalYear;
            $data['englishFiscalYearList'][$fiscalYear] =  $fiscalYear;
        }
        $fiscalYear = FiscalYearSetup::currentFiscalYear();
        $startMonth = $fiscalYear->end_date;
        $startMonth = explode('-', $startMonth);
        $startMonth = (int) $startMonth[1];
        $yearArray = [];
        $firstYear = 2022;
        $lastYear = (int) date('Y');
        $dateConverter = new DateConverter();
        if (isset($filter['employee_id'])) {
            $data['employee'] = $filter['employee_id'];
        }
        for ($i = $firstYear; $i <= $lastYear; $i++) {
            $yearArray[$i] = $i;
        }
        $data['yearList'] = $yearArray;
        $data['monthList'] = $dateConverter->getEngMonths();
        $data['nepaliYearList'] = $dateConverter->getNepYears();
        $data['nepaliMonthList'] = $dateConverter->getNepMonths();
        $ssf_amount = 0;
        if (isset($filter['organization_id']) && (isset($filter['year']) || isset($filter['eng_year']))) {
            if (isset($filter['year']) && $filter['year']) {
                $filter['year'] = $filter['year'];
                $startMonth = $fiscalYear->end_date;
                $startMonth = explode('-', $startMonth);
                $startMonth = (int) $startMonth[1];
            } else {
                $filter['year'] = $filter['eng_year'];
                $startMonth = $fiscalYear->end_date_english;
                $startMonth = explode('-', $startMonth);
                $startMonth = (int) $startMonth[1];
            }
            $explodeFiscalYear = explode('/', $filter['year']);
            $data['year'] =  $year = $explodeFiscalYear[0];
            $payrollModel = Payroll::where(function ($query) use ($year, $startMonth) {
                $query->where(function ($query) use ($year, $startMonth) {
                    $query->where('year', $year)->where('month', '>', $startMonth);
                });
                $query->orWhere(function ($query) use ($year, $startMonth) {
                    $query->where('year', $year + 1)->where('month', '<=', $startMonth);
                });
            })->where('organization_id', $filter['organization_id'])->get();
            $all_ssf = [];
            $data['finalData'] = [];
            $data['deduction'] = [];
            $sumn1 = [];
            $sum = [];
            foreach ($payrollModel as $key => $value) {
                foreach ($value->payrollEmployees as $payrollEmployee => $payrollEmp) {
                    $employeeName = $payrollEmp->employee->getFullName();
                    $employeeModel = $this->employeeObj->find($payrollEmp->employee_id);
                    foreach ($payrollEmp->deductions as $deduction => $ded) {
                        $sum[$ded->title] = $ded->value;
                        // $t[] = [
                        //     "id" => $ded->deduction_setup_id,
                        //     "name" => $ded->title,
                        //     "value" => $ded->value
                        // ];
                    }
                    if (!isset($sumn1[$payrollEmp->employee_id])) {
                        $sumn1[$payrollEmp->employee_id] = [];
                    }
                    foreach ($sum as $k => $v) {
                        if (!isset($sumn1[$payrollEmp->employee_id][$k])) {
                            $sumn1[$payrollEmp->employee_id][$k] = 0;
                        }
                        $sumn1[$payrollEmp->employee_id][$k] = $sumn1[$payrollEmp->employee_id][$k] + $v;
                    }
                    $data['finalData'][$payrollEmp->employee_id] = [
                        'name' => $employeeName,
                        'code' => $employeeModel->employee_code,
                        // 'deduction' => $t,
                        'sum' => $sumn1[$payrollEmp->employee_id]
                    ];
                    $data['deduction'] = ['deduction' => $sumn1[$payrollEmp->employee_id]];
                }
            }
            // dd( $data['finalData']);

            // foreach ($payrollModel as $key => $value) {
            //     $final_ssf = [];
            //     foreach ($value->payrollEmployees as $key => $payrollEmployee) {
            //         if (!isset($filter['employee_id']) || (isset($filter['employee_id']) && ($filter['employee_id'] == $payrollEmployee->employee_id))) {
            //             $ssf_amount = 0;
            //             foreach ($payrollEmployee->deductions as $deduction) {
            //                 if ($deduction->short_name == 'SSF') {
            //                     $amount = $deduction->value ?? 0;
            //                     $ssf_amount += $amount;
            //                 }
            //                 if ($deduction->short_name == 'SSF1') {
            //                     $amount = $deduction->value ?? 0;
            //                     $ssf_amount += $amount;
            //                 } else {
            //                     $amount = 0;
            //                 }
            //             }
            //             $final_ssf[$payrollEmployee->employee->getFullName()] = $ssf_amount;
            //         }
            //     }
            //     $all_ssf[$value->id] = $final_ssf;

            // }

            // dd($all_ssf);
            // $final2_ssf = [];

            // foreach ($all_ssf as $key => $value) {
            //     foreach ($value as $key => $item) {
            //         if (isset($final2_ssf[$key])) {
            //             $final2_ssf[$key] += $item;
            //         } else {
            //             $final2_ssf[$key] = $item;
            //         }
            //         // array_push($data,[$key,$item]);
            //     }
            // }

            // $data['final2_ssf'] = $final2_ssf;

            // dd($final2_ssf);



        }
        // dd($data['employeeList']);
        return view('payroll::ssf-report.report', $data);
    }

    public function tdsReport(Request $request)
    {
        $filter = $request->all();
        // dd($filter);
        $data['organizationList'] = $this->organizationObj->getList();
        $data['branchList'] = $this->branchObj->getList();
        $data['employeePluck'] = $this->employeeObj->getList();
        $yearArray = [];
        $firstYear = 2022;
        $lastYear = (int) date('Y');
        $dateConverter = new DateConverter();
        for ($i = $firstYear; $i <= $lastYear; $i++) {
            $yearArray[$i] = $i;
        }
        $data['yearList'] = $yearArray;
        // $data['payrollModel'] = [];
        $data['monthList'] = $dateConverter->getEngMonths();
        // dd($data['monthList']);
        $data['nepaliYearList'] = $dateConverter->getNepYears();
        $data['nepaliMonthList'] = $dateConverter->getNepMonths();
        if (isset($filter['organization_id']) && (isset($filter['year']) || isset($filter['eng_year']))  && isset($filter['month']) || (isset($filter['eng_month']))) {
            $data['year'] = (isset($filter['year']) && $filter['year']) ? $filter['year'] : $filter['eng_year'];
            $data['month'] = isset($filter['month']) ? $filter['month'] : $filter['eng_month'];
            $payrollModel = Payroll::where('organization_id', $filter['organization_id'])->where('year', $data['year'])->where('month', $data['month'])->first();
            // dd($payrollModel);
            $data['payrollModel'] = $payrollModel;
        }
        // dd($data['payrollModel']);
        return view('payroll::tds-report.report', $data);
    }

    public function branchPayrollReport(Request $request)
    {
        $data = $request->all();
        $dateConverter = new DateConverter();
        $data['branchList'] = $this->branchObj->getList();
        $data['nepaliYearList'] = $dateConverter->getNepYears();
        $data['nepaliMonthList'] = $dateConverter->getNepMonths();
        $data['payrollModel'] = null;


        if (isset($data['branch_id'])) {
            $data['payrollModel'] = $payrollModel = Payroll::where('year', $data['year'])->where('month', $data['month'])->first();
            $data['incomes'] = $payrollModel ? $payrollModel->getIncomes() : [];
            $data['taxExcludeValues'] = $payrollModel ? $payrollModel->getTaxExcludeValues() : [];
            $data['deductions'] = $payrollModel ? $payrollModel->getDeductions() : [];
            $data['payrollEmployees'] = PayrollEmployee::whereHas('employee', function ($query) use ($data) {
                $query->where('branch_id', $data['branch_id']);
            })->whereHas('payroll', function ($query) use ($data) {
                $query->where('year', $data['year'])
                    ->where('month', $data['month']);
            })->where('status', 2)->get();
        }
        return view('payroll::reports.branchwisereport', $data);
    }

    public function branchSummaryReport(Request $request)
    {
        $filter = $request->all();
        $dateConverter = new DateConverter();
        $data['branchList'] = $this->branchObj->getList();
        $data['nepaliYearList'] = $dateConverter->getNepYears();
        $data['nepaliMonthList'] = $dateConverter->getNepMonths();
        $data['payrollModel'] = null;

        if (isset($filter['year']) && isset($filter['month'])) {
            $data['payrollModel'] = $payrollModel = Payroll::where('year', $filter['year'])->where('month', $filter['month'])->first();
            $data['incomes'] = $payrollModel ? $payrollModel->getIncomes() : [];
            $data['taxExcludeValues'] = $payrollModel ? $payrollModel->getTaxExcludeValues() : [];
            $data['deductions'] = $payrollModel ? $payrollModel->getDeductions() : [];
            $payrollId = $payrollModel ? $payrollModel->id : null;
            if (isset($filter['branch_id'])) {
                $data['payrollEmployeeDetails'] = PayrollEmployee::whereHas('employee', function ($query) use ($filter) {
                    $query->where('branch_id', $filter['branch_id']);
                })->where('payroll_id', $payrollId)->where('status', 2)->get()->map(function ($model) {
                    $model->branch = optional(optional($model->employee)->branchModel)->name;
                    return $model;
                })->groupBy('branch');
            } else {
                $data['payrollEmployeeDetails'] = PayrollEmployee::where('payroll_id', $payrollId)->where('status', 2)->get()->map(function ($model) {
                    $model->branch = optional(optional($model->employee)->branchModel)->name;
                    return $model;
                })->groupBy('branch');

                $data['branchWiseIncomeReport'] = Payroll::with([
                    'payrollEmployees.employee.branchModel',
                    'payrollEmployees.incomes',
                ])
                    ->where('id', $payrollId) // Filter by payroll ID
                    ->get()
                    ->flatMap(function ($payroll) {
                        return $payroll->payrollEmployees->flatMap(function ($payrollEmployee) {
                            $branchName = optional($payrollEmployee->employee->branchModel)->name;
                            return $payrollEmployee->incomes
                                ->where('incomeSetup.monthly_income', 11) // Apply the condition here
                                ->map(function ($income) use ($branchName) {
                                    return [
                                        'branch' => $branchName,
                                        'income_setup_id' => $income->income_setup_id,
                                        'value' => $income->value,
                                    ];
                                });
                        });
                    })
                    ->groupBy('branch')
                    ->map(function ($group) {
                        return $group->groupBy('income_setup_id')
                            ->mapWithKeys(function ($incomeGroup, $incomeSetupId) {
                                return [$incomeSetupId => $incomeGroup->sum('value')];
                            });
                    });

                $data['branchWiseDeductionReport'] = Payroll::with([
                    'payrollEmployees.employee.branchModel',
                    'payrollEmployees.deductionModel.deductionSetup', // Load deduction setups
                ])
                    ->where('id', $payrollId)
                    ->get()
                    ->flatMap(function ($payroll) {
                        return $payroll->payrollEmployees->flatMap(function ($payrollEmployee) {
                            $branchName = optional($payrollEmployee->employee->branchModel)->name;

                            return $payrollEmployee->deductionModel
                                ->where('deductionSetup.monthly_deduction', 11) // Apply the condition here
                                ->map(function ($deduction) use ($branchName) {
                                    return [
                                        'branch' => $branchName,
                                        'deduction_setup_id' => $deduction->deduction_setup_id,
                                        'value' => $deduction->value,
                                    ];
                                });
                        });
                    })
                    ->groupBy('branch')
                    ->map(function ($group) {
                        return $group->groupBy('deduction_setup_id')
                            ->mapWithKeys(function ($deductionGroup, $deductionSetupId) {
                                return [$deductionSetupId => $deductionGroup->sum('value')];
                            });
                    });
            }
        }

        return view('payroll::reports.branchsummaryreport', $data);
    }

    public function annualProjectionReport(Request $request)
    {
        $filter = $request->all();
        $data['organizationList'] = $this->organizationObj->getList();
        $data['contractTypeList'] = LeaveType::CONTRACT;
        if (isset($filter['organization_id'])) {
            $fiscalYear = FiscalYearSetup::currentFiscalYear();
            $data['employeeList'] = $this->employeeObj->getList();
            $data['organizationList'] = $this->organizationObj->getList();

            if (isset($filter['organization_id'])) {
                $payrollSetting = PayrollCalenderTypeSetting::where('organization_id',$filter['organization_id'])->first();
                $startMonth = $payrollSetting->calendar_type == 'eng' ? $fiscalYear->end_date_english : $fiscalYear->end_date;
                $startMonth = explode('-', $startMonth);
                $startMonth = (int) $startMonth[1];
                if($payrollSetting->calendar_type == 'eng'){
                    $data['months'] = $months =  [
                        7 => 'July',
                        8 =>  'August',
                        9 => 'September',
                        10 => 'October',
                        11 => 'November',
                        12 => 'December',
                        1 => 'January',
                        2 => 'February',
                        3 => 'March',
                        4 => 'April',
                        5 => 'May',
                        6 => 'June',
                    ];
                }
                else{
                    $data['months'] = $months =  [
                        4 => 'Shrawan',
                        5 =>  'Bhadra',
                        6 => 'Ashwin',
                        7 => 'Kartik',
                        8 => 'Mangsir',
                        9 => 'Poush',
                        10 => 'Magh',
                        11 => 'Falgun',
                        12 => 'Chaitra',
                        1 => 'Baisakh',
                        2 => 'Jestha',
                        3 => 'Ashad',
                    ];
                }
                
                $explodeFiscalYear = $payrollSetting->calendar_type == 'eng' ? explode('/', $fiscalYear->fiscal_year_english) : explode('/', $fiscalYear->fiscal_year);
                $data['year'] =  $year = $explodeFiscalYear[0];
                $data['employees'] = EmployeeSetup::select('employee_id')
                    ->whereHas('employee', function ($query) use ($filter) {
                        $query->where('organization_id', $filter['organization_id']);
                        if (isset($filter['contract_type']) && in_array($filter['contract_type'], [10, 11])) {
                            $query->whereHas('payrollRelatedDetailModel', function ($q) use ($filter) {
                                    $q->where('contract_type', $filter['contract_type']);
                            });
                        }
                    })
                    ->distinct()
                    ->get()
                    ->map(function ($model) use ($months, $startMonth, $year) {
                        $employeee_id = $model->employee_id;

                        $employeeModel = $this->employeeObj->find($employeee_id);
                        $contract_end_date = optional($employeeModel->payrollRelatedDetailModel)->contract_end_date;
                        $terminatedDate = $employeeModel->nep_archived_date;

                        $contract_end_nep_date = $contract_end_date
                            ? date_converter()->eng_to_nep_convert($contract_end_date)
                            : null;

                        $monthlyIncome = EmployeeSetup::whereHas('income', function ($query) use ($employeee_id) {
                            $query->where('monthly_income', 11)
                                ->whereIn('method', [1, 2])
                                ->where('status', 11);
                        })
                            ->where('reference', 'income')
                            ->where('employee_id', $employeee_id)
                            ->sum('amount');

                        foreach ($months as $key => $value) {
                            $currentYear = ($key > $startMonth) ? $year : $year + 1;

                            // Check if contract end or terminated date is before the current year and month
                            $currentNepaliDate = $currentYear . '-' . sprintf("%02d", $key) . '-01';

                            if (
                                ($contract_end_nep_date && $contract_end_nep_date < $currentNepaliDate) ||
                                ($terminatedDate && $terminatedDate < $currentNepaliDate)
                            ) {
                                $month[$value] = 0;
                            } else {
                                $income = PayrollEmployee::whereHas('payroll', function ($query) use ($key, $currentYear, $employeee_id) {
                                    $query->where('year', $currentYear)
                                        ->where('month', $key);
                                })
                                    ->where('employee_id', $employeee_id)
                                    ->where('status', 2)
                                    ->first();

                                if ($income) {
                                    $month[$value] = $income->total_income;
                                } else {
                                    $month[$value] = $monthlyIncome;
                                }
                            }
                        }

                        $model->incomes = $month;
                        return $model;
                    });
            }
        }
        return view('payroll::reports.annualprojection', $data);
    }

    public function YearlyTaxReport(Request $request)
    {
        return view('payroll::yearly-tax-forecast.report');
    }

    public function yearlyPaySlip(Request $request)
    {
        $filter = $request->all();
        // dd($filter);
        $data['organizationList'] = $this->organizationObj->getList();
        $data['branchList'] = $this->branchObj->getList();
        $data['employeePluck'] = $this->employeeObj->getList();
        $data['fiscalYearList'] = $this->fiscalYearObj->find();
        $data['fiscalYear'] = $this->fiscalYearObj->findAll();
        $data['englishFiscalYearList'] = [];
        foreach ($data['fiscalYear'] as $key => $value) {
            $startFiscalDate = $value->start_date_english;
            $endFiscalDate = $value->end_date_english;
            $startFiscalYear = date('Y', strtotime($startFiscalDate));
            $endFiscalYear = date('y', strtotime($endFiscalDate));
            $fiscalYear = $startFiscalYear . '/' . $endFiscalYear;
            $data['englishFiscalYearList'][$fiscalYear] =  $fiscalYear;
        }
        $fiscalYear = FiscalYearSetup::currentFiscalYear();
        $data['setting'] = $this->settingObj->getData();
        $dateConverter = new DateConverter();
        $data['nepaliYearList'] = $dateConverter->getNepYears();
        $data['nepaliMonthList'] = $dateConverter->getNepMonths();
        if (isset($filter['organization_id']) && isset($filter['employee_id']) && (isset($filter['year']) || isset($filter['eng_year']))) {
            $data['employee'] = $this->employeeObj->find($filter['employee_id']);
            $data['incomes'] = $this->incomeSetupObj->getList();
            $data['deductions'] = $this->deductionSetupObj->getMonthlyDeductionList();
            if (isset($filter['year']) && $filter['year']) {
                $filter['year'] = $filter['year'];
                $endMonth = $fiscalYear->end_date;
                $endMonth = explode('-', $endMonth);
                $endMonth = (int) $endMonth[1];
            } else {
                $filter['year'] = $filter['eng_year'];
                $endMonth = $fiscalYear->end_date_english;
                $endMonth = explode('-', $endMonth);
                $endMonth = (int) $endMonth[1];
            }
            $data['paySlipYear'] = $filter['year'];
            $explodeFiscalYear = explode('/', $filter['year']);
            $data['year'] =  $year = $explodeFiscalYear[0];
            $data['payrollEmployee'] = PayrollEmployee::whereHas('payroll', function ($query) use ($year, $endMonth) {
                $query->where(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year + 1)->where('month', '<=', $endMonth);
                });
            })->where('employee_id', $data['employee']->id)->get();
            // dd($data['payrollEmployee']);

            $data['previousTotalIncome'] = PayrollEmployee::whereHas('payroll', function ($query) use ($year, $endMonth) {
                $query->where(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year + 1)->where('month', '<=', $endMonth);
                });
            })->where('employee_id', $data['employee']->id)->sum('total_income');

            $data['previousTotalDeduction'] = PayrollEmployee::whereHas('payroll', function ($query) use ($year, $endMonth) {
                $query->where(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year + 1)->where('month', '<=', $endMonth);
                });
            })->where('employee_id', $data['employee']->id)->sum('total_deduction');
            $data['previousNetSalary'] = PayrollEmployee::whereHas('payroll', function ($query) use ($year, $endMonth) {
                $query->where(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year + 1)->where('month', '<=', $endMonth);
                });
            })->where('employee_id', $data['employee']->id)->sum('net_salary');
            $data['previousSst'] = PayrollEmployee::whereHas('payroll', function ($query) use ($year, $endMonth) {
                $query->where(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year + 1)->where('month', '<=', $endMonth);
                });
            })->where('employee_id', $data['employee']->id)->sum('sst');
            $data['previousTds'] = PayrollEmployee::whereHas('payroll', function ($query) use ($year, $endMonth) {
                $query->where(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year + 1)->where('month', '<=', $endMonth);
                });
            })->where('employee_id', $data['employee']->id)->sum('tds');
            $data['previousAdvance'] = PayrollEmployee::whereHas('payroll', function ($query) use ($year, $endMonth) {
                $query->where(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year + 1)->where('month', '<=', $endMonth);
                });
            })->where('employee_id', $data['employee']->id)->sum('advance_amount');
            $data['fineAndPenalty'] = PayrollEmployee::whereHas('payroll', function ($query) use ($year, $endMonth) {
                $query->where(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year + 1)->where('month', '<=', $endMonth);
                });
            })->where('employee_id', $data['employee']->id)->sum('fine_penalty');
            $data['payableSalary'] = PayrollEmployee::whereHas('payroll', function ($query) use ($year, $endMonth) {
                $query->where(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($year, $endMonth) {
                    $query->where('year', $year + 1)->where('month', '<=', $endMonth);
                });
            })->where('employee_id', $data['employee']->id)->sum('payable_salary');
            return view('payroll::yearly-pay-slip.report', $data);
        }

        return view('payroll::yearly-pay-slip.index', $data);
    }

    /**
     *
     */
    public function departmentwiseReport(Request $request, $payrollId)
    {
        $filter = $request->all();
        $data['payrollModel'] = $this->payrollObj->findOne($payrollId);
        $data['departmentList'] = $this->department->getList();
        // dd($data['departmentList']);
        if (isset($filter['department_id'])) {
            $data['payrollEmployeeDetails'] = PayrollEmployee::whereHas('employee', function ($query) use ($filter) {
                $query->where('department_id', $filter['department_id']);
            })->where('payroll_id', $payrollId)->get()->map(function ($model) {
                $model->department = optional(optional($model->employee)->department)->title;
                return $model;
            })->groupBy('department');
        } else {
            $data['payrollEmployeeDetails'] = PayrollEmployee::where('payroll_id', $payrollId)->get()->map(function ($model) {
                $model->department = optional(optional($model->employee)->department)->title;
                return $model;
            })->groupBy('department');
        }


        return view('payroll::payroll.report.departmentwise', $data);
    }

    /**
     *
     */
    public function irdReport($payrollId)
    {
        $payrollModel = $this->payrollObj->findOne($payrollId);
        $data['payrollModel'] = $payrollModel;
        $data['payrollEmployeeDetails'] = $payrollModel->payrollEmployees;

        return view('payroll::payroll.report.ird', $data);
    }
    public function fnfSettlement(Request $request)
    {
        $filter = $request->all();
        // dd($filter);
        $data['organizationList'] = $this->organizationObj->getList();
        $data['employeeList'] = $this->employeeObj->getList();
        if (isset($filter['organization_id'])) {
            $payrollModel = Payroll::where('organization_id', $filter['organization_id'])->get();
            $all_ssf = [];
            $data['finalData'] = [];
            $data['deduction'] = [];
            $sumn1 = [];
            $sumn2 = [];
            $deductionSum = [];
            $incomeSum = [];
            $totalLeaveAmount = [];
            $totalDeduction = [];
            $totalIncome = [];
            $totalSst = [];
            $totalTds = [];
            $netSalary = [];
            foreach ($payrollModel as $key => $value) {
                foreach ($value->payrollEmployees as $payrollEmployee => $payrollEmp) {
                    if ((isset($filter['employee_id']) && $filter['employee_id'] == $payrollEmp->employee_id) || !isset($filter['employee_id'])) {
                        $employeeName = $payrollEmp->employee->getFullName();
                        $employeeModel = $this->employeeObj->find($payrollEmp->employee_id);
                        $totalDeduction[$payrollEmp->employee_id] = PayrollEmployee::where('employee_id', $payrollEmp->employee_id)->sum('total_deduction');
                        $totalLeaveAmount[$payrollEmp->employee_id] = PayrollEmployee::where('employee_id', $payrollEmp->employee_id)->sum('leave_amount');
                        $totalIncome[$payrollEmp->employee_id] = PayrollEmployee::where('employee_id', $payrollEmp->employee_id)->sum('total_income');
                        $totalSst[$payrollEmp->employee_id] = PayrollEmployee::where('employee_id', $payrollEmp->employee_id)->sum('sst');
                        $totalTds[$payrollEmp->employee_id] = PayrollEmployee::where('employee_id', $payrollEmp->employee_id)->sum('tds');
                        $netSalary[$payrollEmp->employee_id] = PayrollEmployee::where('employee_id', $payrollEmp->employee_id)->sum('net_salary');
                        foreach ($payrollEmp->deductions as $deduction => $ded) {
                            $deductionSum[$ded->title] = $ded->value;
                        }
                        foreach ($payrollEmp->incomes as $income => $inc) {
                            $incomeSum[optional($inc->incomeSetup)->title] = $inc->value;
                        }
                        if (!isset($sumn1[$payrollEmp->employee_id])) {
                            $sumn1[$payrollEmp->employee_id] = [];
                            $sumn2[$payrollEmp->employee_id] = [];
                        }
                        foreach ($deductionSum as $k => $v) {
                            if (!isset($sumn1[$payrollEmp->employee_id][$k])) {
                                $sumn1[$payrollEmp->employee_id][$k] = 0;
                            }
                            $sumn1[$payrollEmp->employee_id][$k] = $sumn1[$payrollEmp->employee_id][$k] + $v;
                        }
                        foreach ($incomeSum as $s => $t) {
                            if (!isset($sumn2[$payrollEmp->employee_id][$s])) {
                                $sumn2[$payrollEmp->employee_id][$s] = 0;
                            }
                            $sumn2[$payrollEmp->employee_id][$s] = $sumn2[$payrollEmp->employee_id][$s] + $t;
                        }

                        $data['finalData'][$payrollEmp->employee_id] = [
                            'name' => $employeeName,
                            'code' => $employeeModel->employee_code,
                            'totalDeduction' => $totalDeduction[$payrollEmp->employee_id],
                            'totalIncome' => $totalIncome[$payrollEmp->employee_id],
                            'totalLeaveAmount' => $totalLeaveAmount[$payrollEmp->employee_id],
                            'totalSst' => $totalSst[$payrollEmp->employee_id],
                            'totalTds' => $totalTds[$payrollEmp->employee_id],
                            'netSalary' => $netSalary[$payrollEmp->employee_id],
                            'deductionSum' => $sumn1[$payrollEmp->employee_id],
                            'incomeSum' => $sumn2[$payrollEmp->employee_id]
                        ];
                        $data['income'] = ['income' => $sumn2[$payrollEmp->employee_id]];

                        $data['deduction'] = ['deduction' => $sumn1[$payrollEmp->employee_id]];
                        // dd($data['income'],$data['deduction']);
                    }
                }
            }
            // dd($data['finalData']);
        }
        return view('payroll::payroll.fnf-settlement.report', $data);
    }




    /**
     * Ajax controller
     */
    public function reCalculate(Request $request)
    {
        $inputData = $request->all();

        $payrollEmployeeId = $inputData['payrollEmployeeId'];
        $totalIncome = $inputData['totalIncome'];
        $totalDeduction = $inputData['totalDeduction'];
        $festivalBonus = $inputData['festivalBonus'];

        $data = [];
        $payrollEmployeeModel = PayrollEmployee::find($payrollEmployeeId);
        if ($payrollEmployeeModel) {
            $data['taxableSalary'] = $payrollEmployeeModel->calculateTaxableSalary($totalIncome, $totalDeduction, $festivalBonus, $payrollEmployeeId);
            $data['sst'] = $payrollEmployeeModel->calculateSST($totalIncome, $totalDeduction, $festivalBonus, $payrollEmployeeId);
            // $data['sst'] = 0;
            $data['tds'] = $payrollEmployeeModel->calculateTDS($totalIncome, $totalDeduction, $festivalBonus, $payrollEmployeeId);
            if (optional(optional($payrollEmployeeModel->employee)->getMaritalStatus)->dropvalue == 'Single' && optional(optional($payrollEmployeeModel->employee)->getGender)->dropvalue == 'Female') {
                $data['single_women_tax'] = round(0.1 * ($data['sst'] + $data['tds']), 2);
            } else {
                $data['single_women_tax'] = 0;
            }
        }

        return response()->json($data, 200);
    }




    public function taxCalculation($id)
    {
        $data['payrollEmployee'] = $payrollEmployee =  $this->payrollObj->findPayrollEmployee($id);
        $data['payrollModel'] = $payrollModel =  $this->payrollObj->findOne($data['payrollEmployee']->payroll_id);
        $fiscalYear = FiscalYearSetup::currentFiscalYear();
        $employeeModel = Employee::where('id', $payrollEmployee->employee_id)->first();

        if ($payrollModel->calendar_type == 'nep') {
            $joinDate = $employeeModel->nepali_join_date;
            $join_month = explode('-', $joinDate);
            $join_month = (int) $join_month[1];
            $start_fiscal_year = Carbon::parse($fiscalYear->start_date)->isoFormat('Y');
            $end_fiscal_date = $fiscalYear->end_date;
            $terminatedDate = $employeeModel->nep_archived_date;
        } else {
            $join_month = Carbon::parse($employeeModel->join_date)->isoFormat('M');
            $joinDate = $employeeModel->join_date;
            $start_fiscal_year = Carbon::parse($fiscalYear->start_date_english)->isoFormat('Y');
            $end_fiscal_date = $fiscalYear->end_date_english;
            $terminatedDate = $employeeModel->archived_date;
        }
        $taxableAmount = 0;
        $endMonth = explode('-', $end_fiscal_date);
        $endMonth = (int) $endMonth[1];

        if ($payrollModel->month > $endMonth) {
            $start_fiscal_year = $payrollModel->year;
        } else {
            $start_fiscal_year = $payrollModel->year - 1;
        }

        if ($payrollModel->calendar_type == 'nep') {
            if ($joinDate < $fiscalYear->start_date) {
                $taxableMonth = 12;
            } else {
                if ($join_month > $endMonth) {
                    $taxableMonth = 12 + $endMonth - $join_month + 1;
                } elseif ($join_month < $endMonth) {
                    $taxableMonth = $endMonth - $join_month + 1;
                } else {
                    $taxableMonth = 1;
                }
            }
        } else {
            if ($joinDate < $fiscalYear->start_date_english) {
                $taxableMonth = 12;
            } else {
                if ($join_month > $endMonth) {
                    $taxableMonth = 12 + $endMonth - $join_month + 1;
                } elseif ($join_month < $endMonth) {
                    $taxableMonth = $endMonth - $join_month + 1;
                } else {
                    $taxableMonth = 1;
                }
            }
        }
        $data['taxableMonth'] = $taxableMonth;

        $data['salaryPaidMonth'] = $salaryPaidMonth = PayrollEmployee::whereHas('payroll', function ($query) use ($start_fiscal_year, $payrollModel, $endMonth) {
            if ($payrollModel->month > $endMonth) {
                $query->where(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year)->where('month', '>', $endMonth)->where('month', '<', (int)$payrollModel->month);
                });
            } else {
                $query->where(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year + 1)->where('month', '<=', $endMonth)->where('month', '<', (int)$payrollModel->month);
                });
            }
        })->where('employee_id', $payrollEmployee->employee_id)->count();


        $data['previousTotalIncome'] = $previousTotalIncome = PayrollEmployee::whereHas('payroll', function ($query) use ($start_fiscal_year, $payrollModel, $endMonth) {
            if ($payrollModel->month > $endMonth) {
                $query->where(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year)->where('month', '>', $endMonth)->where('month', '<', (int)$payrollModel->month);
                });
            } else {
                $query->where(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year + 1)->where('month', '<=', $endMonth)->where('month', '<', (int)$payrollModel->month);
                });
            }
        })->where('employee_id', $payrollEmployee->employee_id)->sum('total_income');


        $employeededuction = EmployeeSetup::whereHas('deduction', function ($query) {
            $query->where('monthly_deduction', 11);
        })->where('reference', 'deduction')->where('employee_id', $employeeModel->id)->pluck('amount', 'id')->toArray();

        $employeeDeduction = EmployeeSetup::whereHas('deduction', function ($query) {
            $query->where('monthly_deduction', 11);
        })->where('reference', 'deduction')->where('employee_id', $employeeModel->id)->get();
        $monthlyDeduction = 0;
        if ($employeededuction) {
            foreach ($employeededuction as $key => $value) {
                $monthlyDeduction = $monthlyDeduction + $value;
            }
        }
        $data['previousTotalDeduction'] = $previousTotalDeduction = PayrollEmployee::whereHas('payroll', function ($query) use ($start_fiscal_year, $payrollModel, $endMonth) {
            if ($payrollModel->month >  $endMonth) {
                $query->where(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year)->where('month', '>', $endMonth)->where('month', '<', (int)$payrollModel->month);
                });
            } else {
                $query->where(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year + 1)->where('month', '<=', $endMonth)->where('month', '<', (int)$payrollModel->month);
                });
            }
        })->where('employee_id', $payrollEmployee->employee_id)->sum('total_deduction');


        $data['totalDeduction'] = $totalDeduction = $payrollEmployee->total_deduction ? $payrollEmployee->total_deduction : 0;
        $data['taxableAmount'] = $taxableAmount = $payrollEmployee->yearly_taxable_salary ? round($payrollEmployee->yearly_taxable_salary, 2) : 0;
        $data['monthlyDeduction'] = $monthlyDeduction;
        $data['taxDetail'] = $this->payrollObj->taxDetail($taxableAmount, $employeeModel);
        return view('payroll::payroll.tax-calculation', $data);
    }



    public function taxCalculationBackup($id)
    {
        $data['payrollEmployee'] = $payrollEmployee =  $this->payrollObj->findPayrollEmployee($id);
        $data['payrollModel'] = $payrollModel =  $this->payrollObj->findOne($data['payrollEmployee']->payroll_id);
        $fiscalYear = FiscalYearSetup::currentFiscalYear();
        $employeeModel = Employee::where('id', $payrollEmployee->employee_id)->first();

        if ($payrollModel->calendar_type == 'nep') {
            $joinDate = $employeeModel->nepali_join_date;
            $join_month = explode('-', $joinDate);
            $join_month = (int) $join_month[1];
            $start_fiscal_year = Carbon::parse($fiscalYear->start_date)->isoFormat('Y');
            $end_fiscal_date = $fiscalYear->end_date;
            $terminatedDate = $employeeModel->nep_archived_date;
        } else {
            $join_month = Carbon::parse($employeeModel->join_date)->isoFormat('M');
            $joinDate = $employeeModel->join_date;
            $start_fiscal_year = Carbon::parse($fiscalYear->start_date_english)->isoFormat('Y');
            $end_fiscal_date = $fiscalYear->end_date_english;
            $terminatedDate = $employeeModel->archived_date;
        }
        $taxableAmount = 0;
        $endMonth = explode('-', $end_fiscal_date);
        $endMonth = (int) $endMonth[1];

        if ($payrollModel->month > $endMonth) {
            $start_fiscal_year = $payrollModel->year;
        } else {
            $start_fiscal_year = $payrollModel->year - 1;
        }

        if ($payrollModel->calendar_type == 'nep') {
            if ($joinDate < $fiscalYear->start_date) {
                $taxableMonth = 12;
            } else {
                if ($join_month > $endMonth) {
                    $taxableMonth = 12 + $endMonth - $join_month + 1;
                } elseif ($join_month < $endMonth) {
                    $taxableMonth = $endMonth - $join_month + 1;
                } else {
                    $taxableMonth = 1;
                }
            }
        } else {
            if ($joinDate < $fiscalYear->start_date_english) {
                $taxableMonth = 12;
            } else {
                if ($join_month > $endMonth) {
                    $taxableMonth = 12 + $endMonth - $join_month + 1;
                } elseif ($join_month < $endMonth) {
                    $taxableMonth = $endMonth - $join_month + 1;
                } else {
                    $taxableMonth = 1;
                }
            }
        }
        $data['taxableMonth'] = $taxableMonth;
        $data['salaryPaidMonth'] = $salaryPaidMonth = PayrollEmployee::whereHas('payroll', function ($query) use ($start_fiscal_year, $payrollModel, $endMonth) {
            if ($payrollModel->month > $endMonth) {
                $query->where(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year)->where('month', '>', $endMonth)->where('month', '<', (int)$payrollModel->month);
                });
            } else {
                $query->where(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year + 1)->where('month', '<=', $endMonth)->where('month', '<', (int)$payrollModel->month);
                });
            }
        })->where('employee_id', $payrollEmployee->employee_id)->count();


        $data['previousTotalIncome'] = $previousTotalIncome = PayrollEmployee::whereHas('payroll', function ($query) use ($start_fiscal_year, $payrollModel, $endMonth) {
            if ($payrollModel->month > $endMonth) {
                $query->where(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year)->where('month', '>', $endMonth)->where('month', '<', (int)$payrollModel->month);
                });
            } else {
                $query->where(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year + 1)->where('month', '<=', $endMonth)->where('month', '<', (int)$payrollModel->month);
                });
            }
        })->where('employee_id', $payrollEmployee->employee_id)->sum('total_income');


        $employeededuction = EmployeeSetup::whereHas('deduction', function ($query) {
            $query->where('monthly_deduction', 11);
        })->where('reference', 'deduction')->where('employee_id', $employeeModel->id)->pluck('amount', 'id')->toArray();

        $employeeDeduction = EmployeeSetup::whereHas('deduction', function ($query) {
            $query->where('monthly_deduction', 11);
        })->where('reference', 'deduction')->where('employee_id', $employeeModel->id)->get();
        $monthlyDeduction = 0;
        if ($employeededuction) {
            foreach ($employeededuction as $key => $value) {
                $monthlyDeduction = $monthlyDeduction + $value;
            }
        }
        $data['previousTotalDeduction'] = $previousTotalDeduction = PayrollEmployee::whereHas('payroll', function ($query) use ($start_fiscal_year, $payrollModel, $endMonth) {
            if ($payrollModel->month >  $endMonth) {
                $query->where(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year)->where('month', '>', $endMonth)->where('month', '<', (int)$payrollModel->month);
                });
            } else {
                $query->where(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year)->where('month', '>', $endMonth);
                });
                $query->orWhere(function ($query) use ($payrollModel, $start_fiscal_year, $endMonth) {
                    $query->where('year', $start_fiscal_year + 1)->where('month', '<=', $endMonth)->where('month', '<', (int)$payrollModel->month);
                });
            }
        })->where('employee_id', $payrollEmployee->employee_id)->sum('total_deduction');


        $attendance = $payrollEmployee->calculateAttendance($payrollModel->calendar_type, $payrollModel->year, $payrollModel->month);
        $leave = $payrollEmployee->calculateLeave($payrollModel->calendar_type, $payrollModel->year, $payrollModel->month);
        $total_paid_leave = $leave['paidLeaveTaken'];
        $total_leave = $leave['unpaid_days'] + $leave['unpaidLeaveTaken'];

        $totalDeduction = 0;
        $totalIncome = 0;
        $totalTaxExcludeAmount = 0;
        $total_days = 0;

        foreach ($payrollEmployee->incomes as $income) {
            if (optional($income->incomeSetup)->monthly_income == 11) {
                $incomeModel = optional($income->incomeSetup);
                if ($incomeModel->daily_basis_status == 11) {
                    if ($attendance['working_days'] == 0) {
                        $incomeAmount = 0;
                    } else {
                        $incomeAmount = $income->value * $attendance['working_days'];
                    }
                } else {
                    $incomeAmount = $income->value;
                }
                if ($incomeModel->short_name == 'SSF') {
                    if ($total_leave > 0) {
                        $incomeAmount = round((($income->value ?? 0) / $attendance['total_days']) * ($attendance['total_days'] - $total_leave), 2);
                    }
                }
                $totalIncome = $totalIncome + $incomeAmount;
            }
        }

        foreach ($payrollEmployee->deductions as $deduction) {
            $deductionModel = optional($deduction->deductionSetup);
            if ($deductionModel->method != 3) {
                if ($total_leave > 0) {
                    $deductionAmount = round((($deduction->value ?? 0) / $attendance['total_days']) * ($attendance['total_days'] - $total_leave), 2);
                } else {
                    $deductionAmount = $deduction->value ?? 0;
                }
            } else {
                $deductionAmount = $deduction->value ?? 0;
            }

            $totalDeduction = $totalDeduction + $deductionAmount;
        }


        $leaveAmount = $payrollEmployee->leave_amount ?? $leave['leave_amount'];
        $fineAndPenalty = $payrollEmployee->fine_penalty ?? 0;
        $data['totalDeduction'] = $totalDeduction = $payrollEmployee->total_deduction ? $payrollEmployee->total_deduction : $totalDeduction + $leaveAmount + $fineAndPenalty;

        $arrear_amount = $payrollEmployee->arrear_amount ?? 0;
        $overTimePay = $payrollEmployee->overtime_pay ?? $attendance['total_ot_amount'];
        $festivalBonus = $payrollEmployee->festival_bonus ? $payrollEmployee->festival_bonus : 0;
        $totalIncome = $payrollEmployee->total_income ? $payrollEmployee->total_income : $totalIncome + $arrear_amount + $overTimePay;
        $data['taxableAmount'] = $taxableAmount = round($payrollEmployee->calculateTaxableSalary($totalIncome, $totalDeduction, $festivalBonus, $payrollEmployee->id), 2);
        $data['monthlyDeduction'] = $monthlyDeduction;
        $data['taxDetail'] = $this->payrollObj->taxDetail($taxableAmount, $employeeModel);
        return view('payroll::payroll.tax-calculation', $data);
    }

    public function payrollReport(Request $request)
    {

        // $payrollModel = $this->payrollObj->latestOne();
        $data['getAllFilterIncome'] = [];
        $data['getAllFilterDeduction'] = [];
        $data['getAllStaticColumn'] = [];
        $query = Payroll::query();
        if ($request->organization_id) {
            $query->where('organization_id', $request->organization_id);
        }
        if ($request->year_id) {
            $query->where('year', $request->year_id);
        }
        if ($request->month_id) {
            $query->where('month', $request->month_id);
        }
        $payrollModel = null;
        $payrollEmployeeAll = null;
        $data['payrollEmployees'] = [];
        if ($request->hasAny(['organization_id', 'year_id', 'month_id'])) {
            if ($request->filled(['organization_id', 'year_id', 'month_id'])) {
                $payrollModel = Payroll::select('payrolls.id')
                    ->where('payrolls.organization_id', $request->get('organization_id'))
                    ->where('payrolls.year', $request->get('year_id'))
                    ->where('payrolls.month', $request->get('month_id'))
                    ->first();

                $CheckPayrollEmployee = PayrollEmployee::where('status', 2)
                    ->where('payroll_id', $payrollModel->id)
                    ->orderBy('updated_at', 'desc')->first();

                if ($CheckPayrollEmployee) {
                    $payrollEmployeeQuery = PayrollEmployee::where('status', 2)
                        ->where('payroll_id', $payrollModel->id)
                        ->orderBy('updated_at', 'desc');
                    $payrollEmployeeAll = $payrollEmployeeQuery;
                    $payrollEmployeeAll = $payrollEmployeeAll->get();
                    if ($request->employee_id) {
                        $payrollEmployeeQuery->where('employee_id', $request->employee_id);
                    }
                    $payrollEmployeeModel = $payrollEmployeeQuery->get();
                    $data['payrollEmployees'] = $payrollEmployeeModel;
                } else {
                    $payrollModel = null;
                }
            }
        } else {
            $payrollEmployeeModel = PayrollEmployee::where('status', 2)
                ->orderBy('updated_at', 'desc')
                ->get();
            $payrollEmployeeAll = $payrollEmployeeModel;
            $data['payrollEmployees'] = $payrollEmployeeModel;
            if (count($payrollEmployeeAll)) {
                $payrollFirstData = $payrollEmployeeAll->first();
                $payrollModel = $query->where('id', $payrollFirstData['payroll_id'])->first();
            }
        }
        $data['payrollEmployees'] = $payrollEmployees = optional($payrollModel)->payrollEmployees;

        $data['calenderType'] = $calenderType = optional($payrollModel)->calendar_type;
        $data['payrollYear'] = $payrollYear = optional($payrollModel)->year;
        $data['payrollMonth'] = $payrollMonth = optional($payrollModel)->month;
        $data['organizationId'] = $organizationId =  optional($payrollModel)->organization_id;
        $data['organizationList'] = $organizationList =  $this->organizationObj->getAll();
        $payrollModelAll = $this->payrollObj->findByOrganizationId($organizationId);
        $data['year'] = $year = $this->getYear($payrollModelAll, optional($payrollModel)->organization_id);
        $data['month'] = $month = $this->getMonth($payrollModelAll, optional($payrollModel)->year);
        $data['payrollModel'] = $payrollModel;
        $data['taxExcludeValues'] = optional($payrollModel)->getTaxExcludeValues();
        $data['deductions'] = $deductions = optional($payrollModel)->getDeductions() ?? [];
        $data['incomes'] = $incomes = optional($payrollModel)->getIncomes() ?? [];

        $data['staticIncomes'] = $staticIncomes = $this->getStaticIncome();
        $data['incomeCount'] = count($incomes) + count($staticIncomes);
        $data['staticDeduction'] = $staticDeduction = $this->getStaticDeduction();
        $data['staticColumn'] = $staticColumn = $this->StaticColumn();
        $data['deductionCount'] = count($deductions) + count($staticDeduction);

        if (!is_null($payrollModel)) {
            $data['getAllFilterIncome'] = $getAllFilterIncome = $this->getAllFilterIncome($incomes, $staticIncomes);
            if ($request->has(['incomes_id']) && !is_null($request->get('incomes_id'))) {

                $filterDatas = $this->getFilterIncome($getAllFilterIncome, $request->get('incomes_id'));
                $data['incomes'] = $incomes = $filterDatas['incomes'];
                $data['incomeCount'] = $filterDatas['count'];
                $data['staticIncomes'] = $staticIncomes = $filterDatas['staticIncomes'];
            }
            $data['getAllFilterDeduction'] = $getAllFilterDeduction = $this->getAllFilterDeduction($deductions, $staticDeduction);
            if ($request->has(['deduction_id']) && !is_null($request->get('deduction_id'))) {
                $filterDatas = $this->getFilterDeduction($getAllFilterDeduction, $request->get('deduction_id'));
                $data['deductions'] = $deductions = $filterDatas['deduction'];
                $data['deductionCount'] = $filterDatas['count'];
                $data['staticDeduction'] = $staticDeduction = $filterDatas['staticDeduction'];
            }

            $data['getAllStaticColumn'] = $getAllStaticColumn = $staticColumn;
            if ($request->has(['column_id']) && !is_null($request->get('column_id'))) {
                $data['staticColumn'] = $staticColumn = $this->getDataByIds($getAllStaticColumn, $request->get('column_id'));
            }
        }
        return view('payroll::reports.index', $data);
    }

    public function citReport(Request $request)
    {
        $query = Payroll::query();
        if ($request->organization_id) {
            $query->where('organization_id', $request->organization_id);
        }
        if ($request->year_id) {
            $query->where('year', $request->year_id);
        }
        if ($request->month_id) {
            $query->where('month', $request->month_id);
        }
        $payrollModel = null;
        $payrollEmployeeAll = null;
        $data['payrollEmployees'] = [];
        if ($request->hasAny(['organization_id', 'year_id', 'month_id'])) {
            if ($request->filled(['organization_id', 'year_id', 'month_id'])) {
                $payrollModel = $query->first();
                if ($payrollModel) {
                    $payrollEmployeeQuery = PayrollEmployee::where('status', 2)
                        ->where('payroll_id', $payrollModel->id)
                        ->orderBy('updated_at', 'desc');
                    $payrollEmployeeAll = $payrollEmployeeQuery;
                    $payrollEmployeeAll = $payrollEmployeeAll->get();
                    if ($request->employee_id) {
                        $payrollEmployeeQuery->where('employee_id', $request->employee_id);
                    }
                    $payrollEmployeeModel = $payrollEmployeeQuery->get();
                    $data['payrollEmployees'] = $payrollEmployeeModel;
                }
            }
        } else {
            $payrollEmployeeModel = PayrollEmployee::where('status', 2)
                ->orderBy('updated_at', 'desc')
                ->get();
            $payrollEmployeeAll = $payrollEmployeeModel;
            $data['payrollEmployees'] = $payrollEmployeeModel;
            if (count($payrollEmployeeAll)) {
                $payrollFirstData = $payrollEmployeeAll->first();
                $payrollModel = $query->where('id', $payrollFirstData['payroll_id'])->first();
            }
        }
        $data['employeeList'] = $employeeList = $this->getEmployeeList($payrollEmployeeAll);

        $data['calenderType'] = $calenderType = optional($payrollModel)->calendar_type;
        $data['organizationId'] = $organizationId =  optional($payrollModel)->organization_id;
        $data['organizationList'] = $organizationList =  $this->organizationObj->getAll();
        $payrollModelAll = $this->payrollObj->findByOrganizationId($organizationId);
        $data['year'] = $year = $this->getYear($payrollModelAll, optional($payrollModel)->organization_id);
        $data['month'] = $month = $this->getMonth($payrollModelAll, optional($payrollModel)->year);
        $data['payrollModel'] = $payrollModel;

        return view('payroll::reports.cit', $data);
    }

    public function ssfReports(Request $request)
    {
        $query = Payroll::query();
        if ($request->organization_id) {
            $query->where('organization_id', $request->organization_id);
        }
        if ($request->year_id) {
            $query->where('year', $request->year_id);
        }
        if ($request->month_id) {
            $query->where('month', $request->month_id);
        }
        $payrollModel = null;
        $payrollEmployeeAll = null;
        $data['payrollEmployees'] = [];
        if ($request->hasAny(['organization_id', 'year_id', 'month_id'])) {
            if ($request->filled(['organization_id', 'year_id', 'month_id'])) {
                $payrollModel = $query->first();
                if ($payrollModel) {
                    $payrollEmployeeQuery = PayrollEmployee::where('status', 2)
                        ->where('payroll_id', $payrollModel->id)
                        ->orderBy('updated_at', 'desc');
                    $payrollEmployeeAll = $payrollEmployeeQuery;
                    $payrollEmployeeAll = $payrollEmployeeAll->get();
                    if ($request->employee_id) {
                        $payrollEmployeeQuery->where('employee_id', $request->employee_id);
                    }
                    $payrollEmployeeModel = $payrollEmployeeQuery->get();
                    $data['payrollEmployees'] = $payrollEmployeeModel;
                }
            }
        } else {
            $payrollEmployeeModel = PayrollEmployee::where('status', 2)
                ->orderBy('updated_at', 'desc')
                ->get();
            $payrollEmployeeAll = $payrollEmployeeModel;
            $data['payrollEmployees'] = $payrollEmployeeModel;
            if (count($payrollEmployeeAll)) {
                $payrollFirstData = $payrollEmployeeAll->first();
                $payrollModel = $query->where('id', $payrollFirstData['payroll_id'])->first();
            }
        }
        $data['employeeList'] = $employeeList = $this->getEmployeeList($payrollEmployeeAll);

        $data['calenderType'] = $calenderType = optional($payrollModel)->calendar_type;
        $data['organizationId'] = $organizationId =  optional($payrollModel)->organization_id;
        $data['organizationList'] = $organizationList =  $this->organizationObj->getAll();
        $payrollModelAll = $this->payrollObj->findByOrganizationId($organizationId);
        $data['year'] = $year = $this->getYear($payrollModelAll, optional($payrollModel)->organization_id);
        $data['month'] = $month = $this->getMonth($payrollModelAll, optional($payrollModel)->year);
        $data['payrollModel'] = $payrollModel;

        return view('payroll::reports.ssf', $data);
    }

    public function pfReport(Request $request)
    {

        $query = Payroll::query();
        if ($request->organization_id) {
            $query->where('organization_id', $request->organization_id);
        }
        if ($request->year_id) {
            $query->where('year', $request->year_id);
        }
        if ($request->month_id) {
            $query->where('month', $request->month_id);
        }
        $payrollModel = null;
        $payrollEmployeeAll = null;
        $data['payrollEmployees'] = [];
        if ($request->hasAny(['organization_id', 'year_id', 'month_id'])) {
            if ($request->filled(['organization_id', 'year_id', 'month_id'])) {
                $payrollModel = $query->first();
                if ($payrollModel) {
                    $payrollEmployeeQuery = PayrollEmployee::where('status', 2)
                        ->where('payroll_id', $payrollModel->id)
                        ->orderBy('updated_at', 'desc');
                    $payrollEmployeeAll = $payrollEmployeeQuery;
                    $payrollEmployeeAll = $payrollEmployeeAll->get();
                    if ($request->employee_id) {
                        $payrollEmployeeQuery->where('employee_id', $request->employee_id);
                    }
                    $payrollEmployeeModel = $payrollEmployeeQuery->get();
                    $data['payrollEmployees'] = $payrollEmployeeModel;
                }
            }
        } else {
            $payrollEmployeeModel = PayrollEmployee::where('status', 2)
                ->orderBy('updated_at', 'desc')
                ->get();
            $payrollEmployeeAll = $payrollEmployeeModel;
            $data['payrollEmployees'] = $payrollEmployeeModel;
            if (count($payrollEmployeeAll)) {
                $payrollFirstData = $payrollEmployeeAll->first();
                $payrollModel = $query->where('id', $payrollFirstData['payroll_id'])->first();
            }
        }
        $data['employeeList'] = $employeeList = $this->getEmployeeList($payrollEmployeeAll);

        $data['calenderType'] = $calenderType = optional($payrollModel)->calendar_type;
        $data['organizationId'] = $organizationId =  optional($payrollModel)->organization_id;
        $data['organizationList'] = $organizationList =  $this->organizationObj->getAll();
        $payrollModelAll = $this->payrollObj->findByOrganizationId($organizationId);
        $data['year'] = $year = $this->getYear($payrollModelAll, optional($payrollModel)->organization_id);
        $data['month'] = $month = $this->getMonth($payrollModelAll, optional($payrollModel)->year);
        $data['payrollModel'] = $payrollModel;

        return view('payroll::reports.pf', $data);
    }

    public function tdsReports(Request $request)
    {

        $query = Payroll::query();
        if ($request->organization_id) {
            $query->where('organization_id', $request->organization_id);
        }
        if ($request->year_id) {
            $query->where('year', $request->year_id);
        }
        if ($request->month_id) {
            $query->where('month', $request->month_id);
        }
        $payrollModel = null;
        $payrollEmployeeAll = null;
        $data['payrollEmployees'] = [];
        if ($request->hasAny(['organization_id', 'year_id', 'month_id'])) {
            if ($request->filled(['organization_id', 'year_id', 'month_id'])) {
                $payrollModel = $query->first();
                if ($payrollModel) {
                    $payrollEmployeeQuery = PayrollEmployee::where('status', 2)
                        ->where('payroll_id', $payrollModel->id)
                        ->orderBy('updated_at', 'desc');
                    $payrollEmployeeAll = $payrollEmployeeQuery;
                    $payrollEmployeeAll = $payrollEmployeeAll->get();
                    if ($request->employee_id) {
                        $payrollEmployeeQuery->where('employee_id', $request->employee_id);
                    }
                    $payrollEmployeeModel = $payrollEmployeeQuery->get();
                    $data['payrollEmployees'] = $payrollEmployeeModel;
                }
            }
        } else {
            $payrollEmployeeModel = PayrollEmployee::where('status', 2)
                ->orderBy('updated_at', 'desc')
                ->get();
            $payrollEmployeeAll = $payrollEmployeeModel;
            $data['payrollEmployees'] = $payrollEmployeeModel;
            if (count($payrollEmployeeAll)) {
                $payrollFirstData = $payrollEmployeeAll->first();
                $payrollModel = $query->where('id', $payrollFirstData['payroll_id'])->first();
            }
        }
        $data['employeeList'] = $employeeList = $this->getEmployeeList($payrollEmployeeAll);

        $data['calenderType'] = $calenderType = optional($payrollModel)->calendar_type;
        $data['organizationId'] = $organizationId =  optional($payrollModel)->organization_id;
        $data['organizationList'] = $organizationList =  $this->organizationObj->getAll();
        $payrollModelAll = $this->payrollObj->findByOrganizationId($organizationId);
        $data['year'] = $year = $this->getYear($payrollModelAll, optional($payrollModel)->organization_id);
        $data['month'] = $month = $this->getMonth($payrollModelAll, optional($payrollModel)->year);
        $data['payrollModel'] = $payrollModel;

        return view('payroll::reports.tds', $data);
    }


    public function getOrganizationYearMonth(Request $request)
    {
        $organizationId = $request->get('organization_id');
        $payrollEmployeesList = [];
        $incomelist = [];
        $deductionList = [];
        $payrollModelAll = $this->payrollObj->findByOrganizationId($organizationId);
        $payrollIds = $this->getPayrollId($payrollModelAll);
        $payrollModel = Payroll::where('id', $payrollIds)->first();
        if (!is_null($payrollModel)) {
            $payrollEmployees = $payrollModel->payrollEmployees;
            $payrollEmployeesList = $this->getEmployeeList($payrollEmployees);

            $incomes = $payrollModel->getIncomes();
            $staticIncomes = $this->getStaticIncome();
            $incomelist = $this->getAllFilterIncome($incomes, $staticIncomes);

            $deductions = $payrollModel->getDeductions();
            $staticDeduction = $this->getStaticDeduction();
            $deductionList = $this->getAllFilterDeduction($deductions, $staticDeduction);
        }

        if (empty($payrollModelAll)) {
            return response()->json([
                'years' => [],
                'months' => [],
                'employee' => [],
                'incomes' => [],
                'deduction' => [],
            ]);
        }
        $years = array_unique(array_column($payrollModelAll, 'year'));
        $yearOptions = array_combine($years, $years);

        $currentYear = max($years);
        $months = $this->getMonth($payrollModelAll, $currentYear);

        return response()->json([
            'years' => $yearOptions,
            'months' => $months,
            'employee' => $payrollEmployeesList,
            'incomes' => $incomelist,
            'deductions' => $deductionList,
        ]);
    }

    public function getOrganizationMonth(Request $request)
    {
        $organizationId = $request->get('organization_id');
        $year = $request->get('year');
        $payrollModelAll = $this->payrollObj->findByOrganizationId($organizationId);
        if (empty($payrollModelAll)) {
            return response()->json([
                'months' => [],
            ]);
        }
        $months = $this->getMonth($payrollModelAll, $year);
        return response()->json([
            'months' => $months,
        ]);
    }

    public function getFilterIncome($incomes, $ids)
    {
        $data = [];
        $checkValues = array_keys($this->getStaticIncome());
        $staticIds = array_filter($ids, function ($value) use ($checkValues) {
            return in_array($value, $checkValues);
        });
        $incomeIds = array_diff($ids, $checkValues);
        $staticIds = array_values($staticIds);
        $incomeIds = array_values($incomeIds);

        $data['incomes'] = $this->getDataByIds($incomes, $incomeIds);
        $data['count'] = count($ids);
        $data['staticIncomes'] = $this->getStaticIncomeByKey($staticIds);
        return $data;
    }

    public function getDataByIds($incomes, $ids)
    {
        $idsAsKeys = array_flip($ids);
        return array_intersect_key($incomes, $idsAsKeys);
    }

    public function getFilterDeduction($deductions, $ids)
    {

        $data = [];
        $checkValues = array_keys($this->getStaticDeduction());
        $staticIds = array_filter($ids, function ($value) use ($checkValues) {
            return in_array($value, $checkValues);
        });
        $deductionIds = array_diff($ids, $checkValues);
        $staticIds = array_values($staticIds);
        $deductionIds = array_values($deductionIds);

        $data['deduction'] = $this->getDataByIds($deductions, $deductionIds);
        $data['count'] = count($ids);
        $data['staticDeduction'] = $this->getStaticDeductionByKey($staticIds);
        return $data;
    }

    public function StaticColumn()
    {

        return [
            '001' => 'Join Date',
            '002' => 'Marital Status',
            '003' => 'Gender',
            '004' => 'Total Days',
            '005' => 'Total Worked Days',
            '006' => 'Extra Working Days',
            '007' => 'Total Paid Leave Days',
            '008' => 'Total Unpaid Leave Days'
        ];
    }

    public function getStaticIncome()
    {
        $incomes['001'] = 'Arrear Amount';
        $incomes['002'] = 'Over-Time Pay';
        return $incomes;
    }

    public function getStaticDeduction()
    {
        $deduction['001'] = 'Leave Amount';
        $deduction['002'] = 'Fine & Penalty';
        return $deduction;
    }

    public function getStaticDeductionByKey($key)
    {
        $staticIncome = $this->getStaticDeduction();
        return $this->getDataByIds($staticIncome, $key);
    }

    public function getStaticIncomeByKey($key)
    {
        $staticIncome = $this->getStaticIncome();
        return $this->getDataByIds($staticIncome, $key);
    }

    public function getAllFilterIncome($incomes, $staticIncomes)
    {
        return $incomes + $staticIncomes;
    }

    public function getAllFilterDeduction($deductions, $staticDeduction)
    {
        return $deductions + $staticDeduction;
    }

    public function getPayrollId($payrollModelAll)
    {
        if (!count($payrollModelAll)) {
            return [];
        }
        $reindexedArray = array_values($payrollModelAll);
        return $reindexedArray[0]['id'] ?? null;
    }

    public function getEmployeeList($payrollEmployeeList)
    {
        if (is_null($payrollEmployeeList)) {
            return [];
        }
        $employeeIds = array_unique(array_column($payrollEmployeeList->toArray(), 'employee_id'));
        return $this->employeeObj->getEmployeeByIDs($employeeIds);
    }

    public function getMonth($payrollModelAll, $year)
    {
        $payrollModelCollection = collect($payrollModelAll);
        $filteredPayrolls = $payrollModelCollection->filter(function ($payroll) use ($year) {
            return $payroll['year'] == $year;
        });
        $calendarType = $filteredPayrolls->first()['calendar_type'] ?? 'nep';
        $months = $filteredPayrolls->pluck('month')->unique();
        $monthNames = $months->mapWithKeys(function ($month) use ($calendarType) {
            if ($calendarType == 'nep') {
                return [$month => date_converter()->_get_nepali_month($month)];
            } else {
                return [$month => date_converter()->_get_english_month($month)];
            }
        });
        return $monthNames->toArray();
    }

    public function getYear($payrollModelAll, $organizationId)
    {
        $filteredPayrolls = array_filter($payrollModelAll, function ($payroll) use ($organizationId) {
            return $payroll['organization_id'] == $organizationId;
        });
        $years = array_column($filteredPayrolls, 'year');
        $years = array_unique($years);
        return array_combine($years, $years);
    }

    public function getBranchData(Request $request)
    {
        $data['values'] = Branch::where('organization_id', $request->organization_id)->get()->pluck('name', 'id');
        $data['fieldId'] = 'branch';
        $data['field_name'] = 'branch_id';
        // dd(view('payroll::payroll.partial.appendMultiFilterData',$data)->render());
        return view('payroll::payroll.partial.appendMultiFilterData', $data);
    }

    public function getUnitData(Request $request)
    {
        $data['values'] = [];
        if ($request->branch_id) {
            $data['values'] = Unit::where('organization_id', $request->organization_id)->whereIn('branch_id', $request->branch_id)->get()->pluck('title', 'id');
        }
        $data['fieldId'] = 'unit';
        $data['field_name'] = 'unit_id';
        return view('payroll::payroll.partial.appendMultiFilterData', $data);
    }
}
