<?php

namespace App\Modules\Payroll\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Contracts\Support\Renderable;
use App\Modules\Payroll\Entities\IncomeSetup;
use Illuminate\Contracts\Validation\Validator;
use App\Modules\Payroll\Entities\EmployeeSetup;
use App\Modules\Setting\Repositories\LevelInterface;
use App\Modules\Payroll\Entities\ThresholdBenefitSetup;
use App\Modules\Employee\Repositories\EmployeeInterface;
use App\Modules\Payroll\Entities\DeductionReferenceSetup;
use App\Modules\Setting\Entities\GrossSalarySetupSetting;
use App\Modules\Payroll\Repositories\IncomeSetupInterface;
use App\Modules\Setting\Repositories\DesignationInterface;
use App\Modules\Payroll\Repositories\DeductionSetupInterface;
use App\Modules\Employee\Entities\EmployeePayrollRelatedDetail;
use App\Modules\Payroll\Entities\DeductionReferenceSetupDetail;
use App\Modules\BusinessTrip\Repositories\BusinessTripInterface;
use App\Modules\Organization\Repositories\OrganizationInterface;
use App\Modules\Employee\Entities\EmployeeThresholdRelatedDetail;
use App\Modules\Payroll\Entities\DeductionReferenceSetupPercentage;

class DeductionSetupController extends Controller
{
    protected $incomeSetup;
    protected $deductionSetup;
    protected $organization;
    protected $employee;
    private $level;
    private $designation;
    private $businessTrip;
    private $deductionReferenceSetup;
    private $deductionReferenceSetupDetail;
    private $deductionReferenceSetUpPercentage;
    public function __construct(
        IncomeSetupInterface $incomeSetup,
        DeductionSetupInterface $deductionSetup,
        OrganizationInterface $organization,
        EmployeeInterface $employee,LevelInterface $level,
        DesignationInterface $designation,
        BusinessTripInterface $businessTrip,
        DeductionReferenceSetup $deductionReferenceSetup,
        DeductionReferenceSetupDetail $deductionReferenceSetupDetail,
        DeductionReferenceSetupPercentage $deductionReferenceSetUpPercentage
    ) {
        $this->businessTrip = $businessTrip;
        $this->incomeSetup = $incomeSetup;
        $this->deductionSetup = $deductionSetup;
        $this->organization = $organization;
        $this->employee = $employee;
        $this->level=$level;
        $this->designation=$designation;
        $this->deductionReferenceSetup=$deductionReferenceSetup;
        $this->deductionReferenceSetupDetail=$deductionReferenceSetupDetail;
        $this->deductionReferenceSetUpPercentage=$deductionReferenceSetUpPercentage;
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $inputData = $request->all();

        $filter = [];
        $sort = ['by' => 'order', 'sort' => 'ASC'];
        
        if(isset($inputData['organization_id'])) {
            $filter['organizationId'] = $inputData['organization_id'];
        }

        $data['organizationList'] = $this->organization->getList();
        $data['deductionSetupModels'] = $this->deductionSetup->findAll(20, $filter, $sort);
        
        return view('payroll::deduction-setup.index', $data);
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        $data['isEdit'] = false;
        $data['organizationList'] = $this->organization->getList();
        $data['incomeList'] = $this->incomeSetup->getList();
        $data['grossSalarySetupSetting']=GrossSalarySetupSetting::first();
        $data['filterSetupDatas']=$this->getGrossSalaryTypeData($data['grossSalarySetupSetting']->gross_salary_type);
        $data['itemsIds'] = collect($data['filterSetupDatas']['filterDatas'])->keys()->toArray();
        $data['allIncomeModels']=IncomeSetup::get()->groupBy('organization_id')->toArray();
        return view('payroll::deduction-setup.create', $data);
    }

    public function getSetupAjaxDataDeduction(Request $request){
        try{
             $selectedIds=$request->seletedids;
             $checkIds=$request->checkIds;
             $data['countValue']=$request->countValue ?? 0;
             if(!$checkIds || $checkIds==null || count($checkIds)<=0){
                 throw new Exception('Select atleast one elements !');
             }
             $grossSetup=GrossSalarySetupSetting::first();
             if(!$grossSetup){
                 throw new Exception('Something Went Wrong !');
             }
             $data['filterSetupDatas']=$this->getGrossSalaryTypeData($grossSetup->gross_salary_type,$selectedIds);
             $data['isEdit'] = false;
             $data['salaryType'] = array_merge(['0' => 'Gross Salary'],$this->incomeSetup->getList()->toArray());
             $response=[
                 'error'=>false,
                 'view'=>view('payroll::deduction-setup.partial.appendDatas',$data)->render(),
                 'msg'=>'success'
             ];
             return response()->json($response,200);
        }catch(\Throwable $th){
             $response=[
                 'error'=>true,
                 'data'=>false,
                 'msg'=>$th->getMessage()
             ];
             return response()->json($response,200);
        }
     }

    public function getGrossSalaryTypeData($grossSalarySetupType,$selectedIds=null){
        $filterValue=[];
        switch($grossSalarySetupType){
            case "1": //Employee
                $filterValue=[
                    'filterName'=>'Employee',
                    'filterDatas'=>$this->employee->getList(),
                ];
                break;
            case "2": //Level
                $filterValue=[
                    'filterName'=>'Level',
                    'filterDatas'=>$this->level->getList()
                ];
                break;
            case "3": //Designation
                $filterValue=[
                    'filterName'=>'Designation',
                    'filterDatas'=>$this->designation->getList()
                ];
                break;
            default:
            break;
        }
        if(isset($selectedIds) && count($selectedIds) > 0){
            $filterValue['filterDatas']=collect($filterValue['filterDatas'])->map(function($item,$key) use ($selectedIds){
                if(!in_array($key,$selectedIds)){
                   return $item;
                }
            })->whereNotNull();
        }
        return $filterValue;
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $inputData = $request->all();
        $deductionData = $request->except('percentage','income_id');
        $deductionData['method']=2;
        $deductionData['amount']=2;
        $grossSalarySetup=GrossSalarySetupSetting::first();
        try {
            $setUpWiseField=$this->businessTrip->arrangeData($grossSalarySetup->gross_salary_type);
            $deductionModel = $this->deductionSetup->save($deductionData);
            if(isset($inputData['setup_level_id']) && count($inputData['setup_level_id']) > 0)
            {
                foreach($inputData['setup_level_id'] as $key=>$levelData){
                    $data=[
                        'deduction_setup_id'=>$deductionModel->id,
                        'organization_id'=>$inputData['organization_id'],
                        'method'=>$inputData['method'][$key] ?? null,
                        'amount'=>$inputData['amount'][$key] ?? null,
                        'setting_setup_type'=>$grossSalarySetup->gross_salary_type
                    ];
                    $this->deductionReferenceSetup=$this->deductionReferenceSetup->create($data);
                    if($this->deductionReferenceSetup){
                        if($inputData['method'][$key]=='2'){
                            $percentageData=[];
                            foreach($inputData['percentage'][$key] as $index=>$percentageValue){
                                $percentageData[]=[
                                    'deduction_reference_setups'=> $this->deductionReferenceSetup->id,
                                    'percentage'=>$percentageValue ?? null,
                                    'income_id'=>$inputData['income_id'][$key][$index] ?? null,
                                ];
                            }
                            DeductionReferenceSetupPercentage::insert($percentageData);
                        }
                        $details=[];
                        foreach($levelData as $selectionId){
                            $details[]=[
                                'deduction_setup_id'=>$deductionModel->id,
                                'deduction_reference_setups'=> $this->deductionReferenceSetup->id,
                                $setUpWiseField=>$selectionId,
                            ];
                        }
                        DeductionReferenceSetupDetail::insert($details);
                    }
                }
            }
            // $deductionModel = $this->deductionSetup->save($deductionData);
            // foreach($inputData['percentage'] as $key=>$value){
            //     if($value){
            //         $deductionDataDetail['deduction_setup_id'] = $deductionModel->id;
            //         $deductionDataDetail['percentage'] = $value;
            //         $deductionDataDetail['income_id'] = $inputData['income_id'][$key];
            //         $this->deductionSetup->saveDetail($deductionDataDetail);
            //     }
                
            //     // dd($deductionDataDetail);
            // }
            toastr()->success('Deduction Setup Created Successfully');
        } catch (\Throwable $e) {
            toastr()->error('Something Went Wrong !!!');
        }
        return redirect(route('deductionSetup.index'));
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('payroll::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $data['isEdit'] = true;
        $data['organizationList'] = $this->organization->getList();
        $data['deductionSetupModel'] = $this->deductionSetup->find($id);
        $data['incomeList'] = $this->incomeSetup->getList();
        $data['grossSalarySetupSetting']=GrossSalarySetupSetting::first();
        $data['filterSetupDatas']=($data['deductionSetupModel']->incomeReferenceSetup && count($data['deductionSetupModel']->incomeReferenceSetup) > 0) ? $this->getGrossSalaryTypeData($data['deductionSetupModel']->incomeReferenceSetup->first()->setting_setup_type)  : $this->getGrossSalaryTypeData(GrossSalarySetupSetting::first()->gross_salary_type);
        $data['itemsIds'] = collect($data['filterSetupDatas']['filterDatas'])->keys()->toArray();
        $data['setUpWiseField']=$this->businessTrip->arrangeData(($data['deductionSetupModel']->incomeReferenceSetup && count($data['deductionSetupModel']->incomeReferenceSetup) > 0) ? $data['deductionSetupModel']->incomeReferenceSetup->first()->setting_setup_type : GrossSalarySetupSetting::first()->gross_salary_type);
        $data['incomeModels']= IncomeSetup::where('organization_id',$data['deductionSetupModel']->organization_id)->pluck('title','id')->toArray();
        $data['allIncomeModels']=IncomeSetup::get()->groupBy('organization_id')->toArray();
        return view('payroll::deduction-setup.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $inputData = $request->all();
        $deductionData = $request->except('percentage','income_id');
        $deductionData['method']=2;
        $deductionData['amount']=2;
        $grossSalarySetup=GrossSalarySetupSetting::first();
        // dd($inputData);
        try {
            $this->deductionSetup->update($id, $deductionData);
            $deductionSetupData=$this->deductionSetup->find($id);
            $setUpWiseField=$this->businessTrip->arrangeData($grossSalarySetup->gross_salary_type);
            $deductionReferenceSetup=$deductionSetupData->deductionReferenceSetup;
            foreach($deductionReferenceSetup as $setUp){
                $setUp->deductionReferenceSetupDetail()->delete();
                $setUp->deductionReferenceSetUpPercentage()->delete();
                $setUp->delete();
            }
            if(isset($inputData['setup_level_id']) && count($inputData['setup_level_id']) > 0)
            {
                foreach($inputData['setup_level_id'] as $key=>$levelData){
                    $data=[
                        'deduction_setup_id'=>$deductionSetupData->id,
                        'organization_id'=>$inputData['organization_id'],
                        'method'=>$inputData['method'][$key] ?? null,
                        'amount'=>$inputData['amount'][$key] ?? null,
                        'setting_setup_type'=>$grossSalarySetup->gross_salary_type
                    ];
                    $this->deductionReferenceSetup=$this->deductionReferenceSetup->create($data);
                    if($this->deductionReferenceSetup){
                        if($inputData['method'][$key]=='2'){
                            $percentageData=[];
                            foreach($inputData['percentage'][$key] as $index=>$percentageValue){
                                $percentageData[]=[
                                    'deduction_reference_setups'=> $this->deductionReferenceSetup->id,
                                    'percentage'=>$percentageValue ?? null,
                                    'income_id'=>$inputData['income_id'][$key][$index] ?? null,
                                ];
                            }
                            DeductionReferenceSetupPercentage::insert($percentageData);
                        }
                        $details=[];
                        foreach($levelData as $selectionId){
                            $details[]=[
                                'deduction_setup_id'=>$deductionSetupData->id,
                                'deduction_reference_setups'=> $this->deductionReferenceSetup->id,
                                $setUpWiseField=>$selectionId,
                            ];
                        }
                        DeductionReferenceSetupDetail::insert($details);
                    }
                }
            }
            // $this->deductionSetup->deleteChild($id);
            // foreach($data['percentage'] as $key=>$value){
            //     if($value){
            //         $deductionDataDetail['deduction_setup_id'] = $id;
            //         $deductionDataDetail['percentage'] = $value;
            //         $deductionDataDetail['income_id'] = $data['income_id'][$key];
            //         $this->deductionSetup->saveDetail($deductionDataDetail);
            //     }
            // }

            toastr()->success('Deduction Setup Updated Successfully');
        } catch (\Throwable $e) {
            toastr()->error('Something Went Wrong !!!');
        }
        return redirect(route('deductionSetup.index'));
    }

    public function checkDeductionOrder(Request $request)
    {
        $data = $request->all();
        $validator = \Validator::make($request->all(), [
            'order' => 'required|unique:deduction_setups,order,' . $data['id'],
        ]);
        if ($validator->fails()) {
            return  json_encode(false);
            // dd($validator->errors()->all());
        }
        return  json_encode(true);
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
      
        try {
            $deductionSetupData=$this->deductionSetup->find($id);
            $deductionReferenceSetup=$deductionSetupData->deductionReferenceSetup;
            foreach($deductionReferenceSetup as $setUp){
                $setUp->deductionReferenceSetupDetail()->delete();
                $setUp->deductionReferenceSetUpPercentage()->delete();
                $setUp->delete();
            }
            $this->deductionSetup->delete($id);
            EmployeeSetup::where('reference','deduction')->where('reference_id',$id)->delete();
            ThresholdBenefitSetup::where('deduction_setup_id',$id)->delete();
            EmployeeThresholdRelatedDetail::where('deduction_setup_id',$id)->delete();
            toastr()->success('Deduction Setup Deleted Successfully');
        } catch (\Throwable $e) {
            toastr()->error('Something Went Wrong !!!');
        }
        return redirect()->back();
    }
    public function getIncomeTypes(Request $request){
        $inputData = $request->all();
        $models= IncomeSetup::where('organization_id',$inputData['organization_id'])->pluck('title','id')->toArray();
        return json_encode($models);
    }
}
