<?php

namespace App\Modules\Payroll\Http\Controllers;

use App\Modules\Admin\Entities\DateConverter;
use App\Modules\Organization\Repositories\OrganizationInterface;
use App\Modules\Payroll\Repositories\BonusSetupInterface;
use App\Modules\Payroll\Repositories\IncomeSetupInterface;
use Illuminate\Contracts\Support\Renderable;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;

class BonusSetupController extends Controller
{
    protected $organization;
    protected $bonusSetup;
    protected $incomeSetup;

    public function __construct(OrganizationInterface $organization,BonusSetupInterface $bonusSetup,IncomeSetupInterface $incomeSetup)
    {
        $this->organization = $organization;
        $this->bonusSetup = $bonusSetup;
        $this->incomeSetup = $incomeSetup;
    }
    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $inputData = $request->all();

        $filter = [];
        $sort = ['by' => 'order', 'sort' => 'ASC'];

        if(isset($inputData['organization_id'])) {
            $filter['organizationId'] = $inputData['organization_id'];
        }

        $data['organizationList'] = $this->organization->getList();
        $data['bonusSetupModels'] = $this->bonusSetup->findAll(20, $filter, $sort);
        return view('payroll::bonus-setup.index',$data);
    }

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        $dateConverter = new DateConverter();
        $data['isEdit'] = false;
        $data['organizationList'] = $this->organization->getList();
        $data['salaryType'] = [1 => 'Basic salary', 2 => 'Gross salary'];
        $data['monthList'] = $dateConverter->getEngMonths();
        $data['nepaliMonthList'] = $dateConverter->getNepMonths();
        return view('payroll::bonus-setup.create', $data);
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $inputData = $request->all();
        // $inputData['tax_applicable_month'] = $inputData['eng_month'] ?? $inputData['month'];
        try {
            $incomeModel = $this->bonusSetup->save($inputData);
            toastr()->success('Bonus Setup Created Successfully');
        } catch (\Throwable $e) {
            toastr()->error('Something Went Wrong !!!');
        }

        return redirect(route('bonusSetup.index'));
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('payroll::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
        $data['isEdit'] = true;
        $data['salaryType'] = [1 => 'Basic salary', 2 => 'Gross salary'];
        $data['organizationList'] = $this->organization->getList();
        $data['monthList'] = date_converter()->getEngMonths();
        $data['nepaliMonthList'] = date_converter()->getNepMonths();
        $data['bonusSetupModel'] = $this->bonusSetup->find($id);

        return view('payroll::bonus-setup.edit', $data);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $data = $request->all();
        // $data['tax_applicable_month'] = $data['eng_month'] ?? $data['month'];

        try {
            $this->bonusSetup->update($id, $data);

            toastr()->success('Bonus Setup Updated Successfully');
        } catch (\Throwable $e) {
            toastr()->error('Something Went Wrong !!!');
        }
        return redirect(route('bonusSetup.index'));
    }

    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        //
    }
}
