<?php

namespace App\Modules\Payroll\Http\Controllers;

use Exception;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Contracts\Support\Renderable;
use App\Modules\Payroll\Entities\IncomeSetup;
use Illuminate\Contracts\Validation\Validator;
use App\Modules\Payroll\Entities\EmployeeSetup;
use App\Modules\Organization\Entities\Organization;
use App\Modules\Setting\Repositories\LevelInterface;
use App\Modules\Payroll\Entities\IncomeReferenceSetup;
use App\Modules\Employee\Repositories\EmployeeInterface;
use App\Modules\Setting\Entities\GrossSalarySetupSetting;
use App\Modules\Payroll\Repositories\IncomeSetupInterface;
use App\Modules\Setting\Repositories\DesignationInterface;
use App\Modules\Payroll\Entities\IncomeReferenceSetupDetail;
use App\Modules\Payroll\Repositories\EmployeeSetupInterface;
use App\Modules\BusinessTrip\Repositories\BusinessTripInterface;
use App\Modules\Organization\Repositories\OrganizationInterface;
use App\Modules\Payroll\Entities\IncomeReferenceSetUpPercentage;

class IncomeSetupController extends Controller
{
    protected $incomeSetup;
    protected $employeeSetup;
    protected $organization;
    protected $employee;
    private $level;
    private $designation;
    private $businessTrip;
    private $incomeReferenceSetup;
    private $incomeReferenceSetupDetail;
    private $incomeReferenceSetUpPercentage;
    public function __construct(IncomeSetupInterface $incomeSetup, EmployeeSetupInterface $employeeSetup, OrganizationInterface $organization,  EmployeeInterface $employee,LevelInterface $level,
    DesignationInterface $designation,BusinessTripInterface $businessTrip,IncomeReferenceSetup $incomeReferenceSetup,IncomeReferenceSetupDetail $incomeReferenceSetupDetail,IncomeReferenceSetUpPercentage $incomeReferenceSetUpPercentage)
    {
        $this->incomeSetup = $incomeSetup;
        $this->businessTrip = $businessTrip;
        $this->employeeSetup = $employeeSetup;
        $this->organization = $organization;
        $this->employee = $employee;
        $this->level=$level;
        $this->designation=$designation;
        $this->incomeReferenceSetup=$incomeReferenceSetup;
        $this->incomeReferenceSetupDetail=$incomeReferenceSetupDetail;
        $this->incomeReferenceSetUpPercentage=$incomeReferenceSetUpPercentage;
    }

    /**
     * Display a listing of the resource.
     * @return Renderable
     */
    public function index(Request $request)
    {
        $inputData = $request->all();

        $filter = [];
        $sort = ['by' => 'order', 'sort' => 'ASC'];
        
        if(isset($inputData['organization_id'])) {
            $filter['organizationId'] = $inputData['organization_id'];
        }

        $data['organizationList'] = $this->organization->getList();
        $data['incomeSetupModels'] = $this->incomeSetup->findAll(20, $filter, $sort);

        return view('payroll::income-setup.index', $data);
    }

    

    /**
     * Show the form for creating a new resource.
     * @return Renderable
     */
    public function create()
    {
        $data['isEdit'] = false;
        $data['organizationList'] = $this->organization->getList();
        // $data['salaryType'] = [1 => 'Basic salary', 2 => 'Gross salary', 3 => 'Grade'];
        $data['salaryType'] =$this->getSalaryType();
        $data['grossSalarySetupSetting']=GrossSalarySetupSetting::first();
        $data['filterSetupDatas']=$this->getGrossSalaryTypeData($data['grossSalarySetupSetting']->gross_salary_type);
        $data['itemsIds'] = collect($data['filterSetupDatas']['filterDatas'])->keys()->toArray();
        return view('payroll::income-setup.create', $data);
    }

    public function getSetupAjaxData(Request $request){
        
       try{
            $selectedIds=$request->seletedids;
            $checkIds=$request->checkIds;
            $data['countValue']=$request->countValue ?? 0;
            if(!$checkIds || $checkIds==null || count($checkIds)<=0){
                throw new Exception('Select atleast one elements !');
            }
            $grossSetup=GrossSalarySetupSetting::first();
            if(!$grossSetup){
                throw new Exception('Something Went Wrong !');
            }
            $data['filterSetupDatas']=$this->getGrossSalaryTypeData($grossSetup->gross_salary_type,$selectedIds);
            $data['isEdit'] = false;
            $data['salaryType'] =$this->getSalaryType(null,$request->organizationId ?? null);
            $response=[
                'error'=>false,
                'view'=>view('payroll::income-setup.partial.appendDatas',$data)->render(),
                'msg'=>'success'
            ];
            return response()->json($response,200);
       }catch(\Throwable $th){
            $response=[
                'error'=>true,
                'data'=>false,
                'msg'=>$th->getMessage()
            ];
            return response()->json($response,200);
       }
    }

    public function getGrossSalaryTypeData($grossSalarySetupType,$selectedIds=null){
        $filterValue=[];
        switch($grossSalarySetupType){
            case "1": //Employee
                $filterValue=[
                    'filterName'=>'Employee',
                    'filterDatas'=>$this->employee->getList(),
                ];
                break;
            case "2": //Level
                $filterValue=[
                    'filterName'=>'Level',
                    'filterDatas'=>$this->level->getList()
                ];
                break;
            case "3": //Designation
                $filterValue=[
                    'filterName'=>'Designation',
                    'filterDatas'=>$this->designation->getList()
                ];
                break;
            default:
            break;
        }
        if(isset($selectedIds) && count($selectedIds) > 0){
            $filterValue['filterDatas']=collect($filterValue['filterDatas'])->map(function($item,$key) use ($selectedIds){
                if(!in_array($key,$selectedIds)){
                   return $item;
                }
            })->whereNotNull();
        }
        return $filterValue;
    }

    /**
     * Store a newly created resource in storage.
     * @param Request $request
     * @return Renderable
     */
    public function store(Request $request)
    {
        $inputData = $request->all();
        $incomeData = $request->except('percentage','salary_type');
        $incomeData['method']=2;
        $incomeData['amount']=2;
        $grossSalarySetup=GrossSalarySetupSetting::first();
        // dd($inputData);
        DB::beginTransaction();
        try {
            $setUpWiseField=$this->businessTrip->arrangeData($grossSalarySetup->gross_salary_type);
            $incomeModel = $this->incomeSetup->save($incomeData);
            if(isset($inputData['setup_level_id']) && count($inputData['setup_level_id']) > 0)
            {
                foreach($inputData['setup_level_id'] as $key=>$levelData){
                    $data=[
                        'income_setup_id'=>$incomeModel->id,
                        'organization_id'=>$inputData['organization_id'],
                        'method'=>$inputData['method'][$key] ?? null,
                        'amount'=>$inputData['amount'][$key] ?? null,
                        'setting_setup_type'=>$grossSalarySetup->gross_salary_type
                    ];
                    $this->incomeReferenceSetup=$this->incomeReferenceSetup->create($data);
                    if($this->incomeReferenceSetup){
                        if($inputData['method'][$key]=='2'){
                            $percentageData=[];
                            foreach($inputData['percentage'][$key] as $index=>$percentageValue){
                                $percentageData[]=[
                                    'income_reference_setups'=> $this->incomeReferenceSetup->id,
                                    'percentage'=>$percentageValue ?? null,
                                    'salary_type'=>$inputData['salary_type'][$key][$index] ?? null,
                                ];
                            }
                            IncomeReferenceSetUpPercentage::insert($percentageData);
                        }
                        $details=[];
                        foreach($levelData as $selectionId){
                            $details[]=[
                                'income_setup_id'=>$incomeModel->id,
                                'income_reference_setups'=> $this->incomeReferenceSetup->id,
                                $setUpWiseField=>$selectionId,
                            ];
                        }
                        IncomeReferenceSetupDetail::insert($details);
                    }
                }
            }
            // foreach($inputData['percentage'] as $key=>$value){
            //     if($value){
            //         $incomeDataDetail['income_setup_id'] = $incomeModel->id;
            //         $incomeDataDetail['percentage'] = $value;
            //         $incomeDataDetail['salary_type'] = $inputData['salary_type'][$key];
            //         $this->incomeSetup->saveDetail($incomeDataDetail);
            //     }
            // }
            DB::commit();
            toastr()->success('Income Setup Created Successfully');
        } catch (\Throwable $e) {
            toastr()->error('Something Went Wrong !!!');
        }

        return redirect(route('incomeSetup.index'));
    }

    /**
     * Show the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function show($id)
    {
        return view('payroll::show');
    }

    /**
     * Show the form for editing the specified resource.
     * @param int $id
     * @return Renderable
     */
    public function edit($id)
    {
       
        $data['incomeSetupModel'] = $this->incomeSetup->find($id);
        $data['isEdit'] = false;    
        $data['organizationList'] = $this->organization->getList();
        $data['salaryType'] =$this->getSalaryType($id,$data['incomeSetupModel']->organization_id);
        $data['filterSetupDatas']=($data['incomeSetupModel']->incomeReferenceSetup && count($data['incomeSetupModel']->incomeReferenceSetup) > 0) ? $this->getGrossSalaryTypeData($data['incomeSetupModel']->incomeReferenceSetup->first()->setting_setup_type)  : $this->getGrossSalaryTypeData(GrossSalarySetupSetting::first()->gross_salary_type);
        $data['itemsIds'] = collect($data['filterSetupDatas']['filterDatas'])->keys()->toArray();
        $data['setUpWiseField']=$this->businessTrip->arrangeData(($data['incomeSetupModel']->incomeReferenceSetup && count($data['incomeSetupModel']->incomeReferenceSetup) > 0) ? $data['incomeSetupModel']->incomeReferenceSetup->first()->setting_setup_type : GrossSalarySetupSetting::first()->gross_salary_type);
        return view('payroll::income-setup.edit', $data);
    }
    

    public function getSalaryType($id=null,$organizationId=null){
        $data=[];
        $data[0]='Gross Salary';
        $organizationId=$organizationId ?? null;
        IncomeSetup::
        when($organizationId,function($item,$value){
            $item->where('organization_id','=',$value);
        })
        ->when($id,function($item,$value){
            $item->where('id','!=',$value);
        })
        ->orderBy('order','asc')->get()->map(function($item) use (&$data){
            $data[$item->id]=$item->title;
        });
        return $data;
    }

    public function getSalaryTypeFilter(Request $request){
        $organizationId=$request->organizationId ?? null;
        $data=[];
        $data[0]='Gross Salary';
        IncomeSetup::
        when($organizationId,function($item,$value){
            $item->where('organization_id','=',$value);
        })
        ->orderBy('order','asc')->get()->map(function($item) use (&$data){
            $data[$item->id]=$item->title;
        });
       return response()->json($data,200);
    }

    /**
     * Update the specified resource in storage.
     * @param Request $request
     * @param int $id
     * @return Renderable
     */
    public function update(Request $request, $id)
    {
        $data = $request->all();
        $inputData = $request->all();
        $incomeData = $request->except('percentage','salary_type');
        $incomeData['method']=2;
        $incomeData['amount']=2;
        $grossSalarySetup=GrossSalarySetupSetting::first();
        try {
            $this->incomeSetup->update($id, $incomeData);
            $this->incomeSetup->deleteChild($id);
            $incomeSetupData=$this->incomeSetup->find($id);
            $setUpWiseField=$this->businessTrip->arrangeData($grossSalarySetup->gross_salary_type);
            $incomeReferenceSetup=$incomeSetupData->incomeReferenceSetup;
            foreach($incomeReferenceSetup as $setUp){
                $setUp->incomeReferenceSetupDetail()->delete();
                $setUp->incomeReferenceSetUpPercentage()->delete();
                $setUp->delete();
            }
            if(isset($inputData['setup_level_id']) && count($inputData['setup_level_id']) > 0)
            {
                foreach($inputData['setup_level_id'] as $key=>$levelData){
                    // dd($inputData['amount'][$key]);
                    $data=[
                        'income_setup_id'=>$id,
                        'organization_id'=>$inputData['organization_id'],
                        'method'=>$inputData['method'][$key] ?? null,
                        'amount'=>$inputData['amount'][$key] ?? null,
                        'setting_setup_type'=>$grossSalarySetup->gross_salary_type
                    ];
                    $this->incomeReferenceSetup=$this->incomeReferenceSetup->create($data);
                    if($this->incomeReferenceSetup){
                        if($inputData['method'][$key]=='2'){
                            $percentageData=[];
                            foreach($inputData['percentage'][$key] as $index=>$percentageValue){
                                $percentageData[]=[
                                    'income_reference_setups'=> $this->incomeReferenceSetup->id,
                                    'percentage'=>$percentageValue ?? null,
                                    'salary_type'=>$inputData['salary_type'][$key][$index] ?? null,
                                ];
                            }
                            IncomeReferenceSetUpPercentage::insert($percentageData);
                        }
                        $details=[];
                        foreach($levelData as $selectionId){
                            $details[]=[
                                'income_setup_id'=>$id,
                                'income_reference_setups'=> $this->incomeReferenceSetup->id,
                                $setUpWiseField=>$selectionId,
                            ];
                        }
                        IncomeReferenceSetupDetail::insert($details);
                    }
                }
            }

            // foreach($data['percentage'] as $key=>$value){
            //     if($value){
            //         $incomeDataDetail['income_setup_id'] = $id;
            //         $incomeDataDetail['percentage'] = $value;
            //         $incomeDataDetail['salary_type'] = $data['salary_type'][$key];
            //         $this->incomeSetup->saveDetail($incomeDataDetail);
            //     }
            // }

            toastr()->success('Income Setup Updated Successfully');
        } catch (\Throwable $e) {
            toastr()->error('Something Went Wrong !!!');
        }
        return redirect(route('incomeSetup.index'));
    }

    public function checkIncomeOrder(Request $request)
    {
        $data = $request->all();
        $validator = \Validator::make($request->all(), [
            'order' => 'required|unique:income_setups,order,' . $data['id'],
        ]);
        if ($validator->fails()) {
            return  json_encode(false);
            // dd($validator->errors()->all());
        }
        return  json_encode(true);
    }


    /**
     * Remove the specified resource from storage.
     * @param int $id
     * @return Renderable
     */
    public function destroy($id)
    {
        try {
            $incomeSetupData=$this->incomeSetup->find($id);
            $incomeReferenceSetup=$incomeSetupData->incomeReferenceSetup;
            foreach($incomeReferenceSetup as $setUp){
                $setUp->incomeReferenceSetupDetail()->delete();
                $setUp->incomeReferenceSetUpPercentage()->delete();
                $setUp->delete();
            }
            $this->incomeSetup->delete($id);
            EmployeeSetup::where('reference', 'income')->where('reference_id', $id)->delete();
            toastr()->success('Income Setup Deleted Successfully');
        } catch (\Throwable $e) {
            toastr()->error('Something Went Wrong !!!');
        }
        return redirect()->back();
    }
}
