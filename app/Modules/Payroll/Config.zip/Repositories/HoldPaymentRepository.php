<?php

namespace App\Modules\Payroll\Repositories;

use App\Modules\Payroll\Entities\HoldPayment;

class HoldPaymentRepository implements HoldPaymentInterface
{
    public function findAll($limit = null, $filter = [], $sort = ['by' => 'id', 'sort' => 'ASC'], $status = [0, 1])
    {
        $result = HoldPayment::query();
        if (isset($filter['organizationId'])) {
            $result->where('organization_id', $filter['organizationId']);
        }
        $result = $result->orderBy($sort['by'], $sort['sort'])->paginate($limit ? $limit : env('DEF_PAGE_LIMIT', 9999));
        return $result;
    }

    public function find($id)
    {
        return HoldPayment::find($id);
    }

    public function getList($params = [])
    {
        if (isset($params['organizationId'])) {
            $result = HoldPayment::where('organization_id', $params['organizationId'])->pluck('title', 'id');
        } else {
            $result = HoldPayment::pluck('title', 'id');
        }

        return $result;
    }

    public function save($data)
    {
        return HoldPayment::create($data);
    }

    public function update($id, $data)
    {
        $result = HoldPayment::find($id);
        return $result->update($data);
    }
    public function updateStatus($data)
    {
        $result = HoldPayment::where('year', $data['year'])->where('month', $data['month'])->where('organization_id', $data['organization_id'])->where('employee_id', $data['employee_id'])->first();
        // dd($result);
        return $result->update($data);
    }
    public function getStatus()
    {
        return HoldPayment::STATUS;
    }
    public function delete($id)
    {
        return HoldPayment::destroy($id);
    }
    public function getHoldPayment($year, $month, $organizationId)
    {
        return HoldPayment::where('year', $year)->where('month', $month)->where('organization_id', $organizationId)->get();
    }

    public function getHoldPaymentEmployee($year, $month, $organizationId)
    {
        return HoldPayment::where('year', $year)->where('month', $month)->where('organization_id', $organizationId)->pluck('employee_id')->toArray();
    }

    public function getHoldPaymentEmployeeWithStatus($year, $month, $organizationId)
    {
        return HoldPayment::where('year', $year)->where('month', $month)->where('organization_id', $organizationId)->where('status',1)->pluck('employee_id')->toArray();
    }

    public function getHoldPaymentEmployeeNameList($year, $month, $organizationId)
    {
        $data = [];
        $holdPayments = HoldPayment::where('year', $year)->where('month', $month)->where('status', 1)->where('organization_id', $organizationId)
            ->get();

        if ($holdPayments->count() > 0) {
            foreach ($holdPayments as $holdPayment) {
                $data[$holdPayment->employee_id] = optional($holdPayment->employeeModel)->full_name;
            }
        }

        return $data;
    }

    public function getAllHoldPaymentByEmployee($id)
    {
        return HoldPayment::where('employee_id', $id)->where('status', 1)->get();
    }
}
