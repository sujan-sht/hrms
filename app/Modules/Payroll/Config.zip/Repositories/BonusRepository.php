<?php

namespace App\Modules\Payroll\Repositories;

use App\Modules\Admin\Entities\DateConverter;
use App\Modules\Payroll\Entities\Bonus;
use App\Modules\Payroll\Entities\BonusEmployee;
use App\Modules\Payroll\Entities\BonusIncome;
use App\Modules\Payroll\Entities\BonusSetup;
use App\Modules\Payroll\Entities\EmployeeBonusSetup;
use Illuminate\Support\Facades\DB;
use App\Modules\Payroll\Entities\EmployeeSetup;

class BonusRepository implements BonusInterface
{
    public function __construct(

    ) {
        
    }
    public function findAll($limit = null, $filter = [], $sort = ['by' => 'id', 'sort' => 'DESC'])
    {
        $authUser = auth()->user();
        if($authUser->user_type == 'division_hr') {
            $filter['organization'] = optional($authUser->userEmployer)->organization_id;
        }
        $result = Bonus::query();
        if (isset($filter['organization'])) {
            $result->where('organization_id', $filter['organization']);
        }
        if (isset($filter['year'])) {
            $result->where('year', $filter['year']);
        }
        if (isset($filter['month'])) {
            $result->where('month', $filter['month']);
        }
        $result = $result->orderBy($sort['by'], $sort['sort'])->paginate($limit ? $limit : env('DEF_PAGE_LIMIT', 9999));
        return $result;
    }

    public function findOne($id)
    {
        return Bonus::find($id);
    }

    public function create($data)
    {
        DB::beginTransaction();

        try {
            $bonusModel = Bonus::create($data);
            $params['organization_id'] = $bonusModel->organization_id;
            $data['field'] = $bonusModel->calendar_type == 'eng' ? 'archived_date' : 'nep_archived_date';
            $employees = EmployeeBonusSetup::select('employee_id')->whereHas('employee', function ($query) use ($params, $bonusModel, $data) {
                        $query->where('organization_id', $params)->where(function ($query) use ($bonusModel,$data) {
                            $query->where('status', 1)->orWhere(function ($query) use ($bonusModel,$data) {
                                $query->whereYear($data['field'], $bonusModel->year)->whereMonth($data['field'], $bonusModel->month);
                            });
                        });
                    })->distinct()->get();

            foreach ($employees as $employee) {
                    $bonusEmployeeData = [];
                    $bonusEmployeeData['bonus_id'] = $bonusModel->id;
                    $bonusEmployeeData['employee_id'] = $employee->employee_id;
                    $bonusEmployeeModel = BonusEmployee::create($bonusEmployeeData);

                    $totalIncome = 0;
                    $incomes = EmployeeBonusSetup::select('bonus_setup_id')->whereHas('bonusSetup', function ($query) use ($params) {
                        if (isset($params['organization_id'])) {
                            $query->where('organization_id', $params['organization_id']);
                        }
                        $query->where('status', 11);
                    })->distinct()->get()->map(function ($model) {
                        $model->sort = optional($model->bonusSetup)->order;
                        return $model;
                    })->sortBy('sort');

                    foreach ($incomes as $income) {
                        $employeeBonusSetupModel = EmployeeBonusSetup::where(['bonus_setup_id' => $income->bonus_setup_id, 'employee_id' => $employee->employee_id])->first();
                        if (isset($employeeBonusSetupModel)) {
                            $amount = $employeeBonusSetupModel->amount ?: 0;
                        } else {
                            $amount = 0;
                        }
                        $totalIncome += $amount;
                        $bonusIncomeData = [];
                        $bonusIncomeData['bonus_id'] = $bonusModel->id;
                        $bonusIncomeData['bonus_employee_id'] = $bonusEmployeeModel->id;
                        $bonusIncomeData['bonus_setup_id'] = $income->bonus_setup_id;
                        $bonusIncomeData['value'] = $amount;
                        BonusIncome::create($bonusIncomeData);
                    }

                    $bonusEmployeeModel->total_income = $totalIncome;
                    $bonusEmployeeModel->save();
                
            }        
            

            // all good
            DB::commit();
        } catch (\Exception $e) {
            throw $e;
            // something went wrong
            DB::rollBack();
        }
    }

    public function update($id, $data)
    {
        $result = Payroll::find($id);
        return $result->update($data);
    }

    public function delete($id)
    {
        DB::beginTransaction();

        try {
            $bonusEmployeeModels = BonusEmployee::where('bonus_id', $id)->get();
            foreach ($bonusEmployeeModels as $bonusEmployeeModel) {
                BonusIncome::where('bonus_employee_id', $bonusEmployeeModel->id)->delete();
                $bonusEmployeeModel->delete();
            }
            Bonus::destroy($id);

            DB::commit();
        } catch (\Exception $e) {
            DB::rollBack();
        }

        return true;
    }

}
