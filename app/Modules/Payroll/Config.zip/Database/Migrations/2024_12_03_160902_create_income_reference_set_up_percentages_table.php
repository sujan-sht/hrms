<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateIncomeReferenceSetUpPercentagesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('income_reference_set_up_percentages', function (Blueprint $table) {
            $table->id();
            $table->integer('income_reference_setups');
            $table->float('percentage', 10, 2)->nullable();
            $table->integer('salary_type')->nullable()->comment('1 => basic, 2 => gross, 3 => grade');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('income_reference_set_up_percentages');
    }
}
