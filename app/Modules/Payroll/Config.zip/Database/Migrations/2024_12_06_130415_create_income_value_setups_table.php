<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateIncomeValueSetupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('income_value_setups', function (Blueprint $table) {
            $table->id();
            $table->integer('organization_id');
            $table->integer('level_id')->nullable();
            $table->integer('designation_id')->nullable();
            $table->integer('employee_id')->nullable();
            $table->string('gross_setup_type');
            $table->string('reference')->comment('income or deduction');
            $table->integer('reference_id')->nullable();
            $table->float('amount', 10, 2)->nullable();
            $table->integer('status')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('income_value_setups');
    }
}

