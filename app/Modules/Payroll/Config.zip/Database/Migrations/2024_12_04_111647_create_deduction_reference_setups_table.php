<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDeductionReferenceSetupsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('deduction_reference_setups', function (Blueprint $table) {
            $table->id();
            $table->integer('deduction_setup_id');
            $table->integer('organization_id');
            $table->integer('method')->nullable()->comment('1 => fixed, 2 => percentage');
            $table->float('amount', 10, 2)->nullable();
            $table->string('setting_setup_type');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('deduction_reference_setups');
    }
}
