<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateGrossSalaryWiseDataTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('gross_salary_wise_data', function (Blueprint $table) {
            $table->id();
            $table->integer('organization_id')->nullable();
            $table->integer('level_id')->nullable();
            $table->integer('designation_id')->nullable();
            $table->integer('employee_id')->nullable();
            $table->double('gross_salary', 16, 2)->nullable();
            $table->double('grade', 16, 2)->nullable();
            $table->string('gross_salary_setup_type');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('gross_salary_wise_data');
    }   
}
