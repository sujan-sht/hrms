<?php

namespace App\Modules\Payroll\Entities;

use Illuminate\Database\Eloquent\Model;
use App\Modules\Employee\Entities\Employee;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class IncomeValueSetup extends Model
{
    protected $fillable = [
        'organization_id',
        'level_id',
        'designation_id',
        'employee_id',
        'gross_setup_type',
        'amount',
        'status',
        'reference',
        'reference_id'
    ];

    public function income()
    {
        return $this->belongsTo(IncomeSetup::class, 'reference_id', 'id');
    }

    public function employee()
    {
        return $this->belongsTo(Employee::class, 'employee_id', 'id');
    }

    public function deduction()
    {
        return $this->belongsTo(DeductionSetup::class, 'reference_id', 'id');
    }
}
