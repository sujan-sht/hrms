<?php

namespace App\Modules\Payroll\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Modules\Payroll\Entities\DeductionReferenceSetupDetail;
use App\Modules\Payroll\Entities\DeductionReferenceSetupPercentage;

class DeductionReferenceSetup extends Model
{
    

    protected $fillable = [
        'deduction_setup_id',
        'organization_id',
        'method',
        'amount',
        'setting_setup_type'
    ];

    public function deductionReferenceSetupDetail(){
        return $this->hasMany(DeductionReferenceSetupDetail::class,'deduction_reference_setups','id');
    }

    public function deductionReferenceSetUpPercentage(){
        return $this->hasMany(DeductionReferenceSetupPercentage::class,'deduction_reference_setups','id');
    }
    
 
}
