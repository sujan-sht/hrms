<?php

namespace App\Modules\Payroll\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class IncomeSetupReferenceSalaryType extends Model
{
    protected $fillable = [
        'income_setup_id',
        'percentage',
        'salary_type'
    ];
    public function getSalaryType($salary_type){
        switch ($salary_type) {
            case 1:
                $salary_type = "Basic Salary";
                break;

            case 2:
                $salary_type = "Gross Salary";
                break;

            case 3:
                $salary_type = "Grade";
                break;
        }
        return $salary_type;
    }
}
