<?php

namespace App\Modules\Payroll\Entities;

use App\Modules\Organization\Entities\Organization;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class BonusSetup extends Model
{
    protected $fillable = [
        'organization_id',
        'title',
        'short_name',
        'description',
        'method',
        'amount',
        'percentage',
        'salary_type',
        'order',
        'status',
        'tax_applicable_month'
    ];

    public function organization()
    {
        return $this->belongsTo(Organization::class, 'organization_id');
    }
    public static function statusList()
    {
        return [
            '10' => 'Inactive',
            '11' => 'Active',
        ];
    }

    public function getStatusWithColor()
    {
        $list = Self::statusList();

        switch ($this->status) {
            case '11':
                $color = 'success';
            break;
            case '10':
                $color = 'danger';
            break;
            default:
                $color = 'secondary';
            break;
        }

        return [
            'status' => $list[$this->status],
            'color' => $color
        ];
    }

    public static function methodList()
    {
        return [
            '1' => 'Fixed',
            '2' => 'Percentage',
            '3' => 'Manual'
        ];
    }

    public function getMethod()
    {
        $list = Self::methodList();

        return [
            'method' => $list[$this->method],
        ];
    }
}
