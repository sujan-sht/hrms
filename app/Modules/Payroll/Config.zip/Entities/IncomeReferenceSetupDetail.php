<?php

namespace App\Modules\Payroll\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class IncomeReferenceSetupDetail extends Model
{

    protected $fillable = [
        'income_setup_id',
        'income_reference_setups',
        'level_id',
        'designation_id',
        'employee_id'
       
    ];
    

    public function incomeReferenceSetup(){
        return $this->hasOne(IncomeReferenceSetup::class,'id','income_reference_setups');
    }
}
