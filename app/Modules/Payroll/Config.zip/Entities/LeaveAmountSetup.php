<?php

namespace App\Modules\Payroll\Entities;

use App\Modules\Organization\Entities\Organization;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class LeaveAmountSetup extends Model
{
    protected $fillable = ['organization_id','income_setup_id'];

    public function organizationModel(){
        return $this->belongsTo(Organization::class,'organization_id');
    }

    public function leaveAmountDetail(){
        return $this->hasMany(LeaveAmountSetupDetail::class,'leave_amount_setup_id','id');
    }
   
}
