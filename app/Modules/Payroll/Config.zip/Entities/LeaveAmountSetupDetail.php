<?php

namespace App\Modules\Payroll\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class LeaveAmountSetupDetail extends Model
{
    protected $fillable = ['leave_amount_setup_id','income_setup_id'];

    public function income(){
        return $this->belongsTo(IncomeSetup::class,'income_setup_id');
    }

}
