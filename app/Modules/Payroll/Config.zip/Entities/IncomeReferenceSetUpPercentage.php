<?php

namespace App\Modules\Payroll\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class IncomeReferenceSetUpPercentage extends Model
{
   protected $fillable=[
        'income_reference_setups',
        'percentage',
        'salary_type'
   ];
}
