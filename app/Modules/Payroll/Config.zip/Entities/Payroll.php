<?php

namespace App\Modules\Payroll\Entities;

use App\Modules\Unit\Entities\Unit;
use App\Modules\Branch\Entities\Branch;
use Illuminate\Database\Eloquent\Model;
use App\Modules\Admin\Entities\DateConverter;
use App\Modules\Organization\Entities\Organization;

class Payroll extends Model
{

    protected $fillable = [
        'organization_id',
        'calendar_type',
        'year',
        'month',
        'account_status',
        'created_by',
        'created_by_modal',
        'finalized_by',
        'finalized_by_modal',
        'branch_id',
        'unit_id'
    ];

    public function branch(){
        return $this->hasOne(Branch::class,'id','branch_id');
    }
    public function unit(){
        return $this->hasOne(Unit::class,'id','unit_id');
    }
    /**
     *
     */
    public function organization()
    {
        return $this->belongsTo(Organization::class, 'organization_id');
    }

    /**
     *
     */
    public function payrollEmployees()
    {
        return $this->hasMany(PayrollEmployee::class)->orderBy('employee_id', 'ASC');
    }

    /**
     *
     */
    public function payrollEmployee()
    {
        return $this->hasOne(PayrollEmployee::class);
    }

    /**
     * 
     */
    public function getIncomes()
    {
        $result = [];

        $payrollIncomeModels = PayrollIncome::whereHas('incomeSetup', function($query) {
            $query->where('monthly_income', 11);
        })->where('payroll_id', $this->id)->where('payroll_employee_id', $this->payrollEmployee->id)->orderBy('id', 'ASC')->get();
        if($payrollIncomeModels) {
            foreach ($payrollIncomeModels as $payrollIncomeModel) {
                $result[$payrollIncomeModel->income_setup_id] = optional($payrollIncomeModel->incomeSetup)->title;
            }
        }
        
        return $result;
    } 

    /**
     * 
     */
    public function getDeductions()
    {
        $result = [];

        $payrollDeductionModels = PayrollDeduction::whereHas('deductionSetup', function($query) {
            $query->where('monthly_deduction', 11);
        })->where('payroll_id', $this->id)->where('payroll_employee_id', $this->payrollEmployee->id)->orderBy('id', 'ASC')->get();
        if($payrollDeductionModels) {
            foreach ($payrollDeductionModels as $payrollDeductionModel) {
                $result[$payrollDeductionModel->deduction_setup_id] = optional($payrollDeductionModel->deductionSetup)->title;
            }
        }
        
        return $result;
    } 

    public function getTaxExcludeValues()
    {
        $result = [];

        $payrollTaxExcludeModels = PayrollTaxExcludeValue::where('payroll_id', $this->id)->where('payroll_employee_id', $this->payrollEmployee->id)->orderBy('id', 'ASC')->get();
        if($payrollTaxExcludeModels) {
            foreach ($payrollTaxExcludeModels as $payrollTaxExcludeModel) {
                $result[$payrollTaxExcludeModel->tax_exclude_setup_id] = optional($payrollTaxExcludeModel->taxExcludeSetup)->title;
            }
        }
        
        return $result;
    } 

    /**
     *
     */
    public function getMonthTitleAttribute()
    {
        $title = '';
        $dateConverter = new DateConverter();

        if($this->calendar_type == 'eng') {
            $title = $dateConverter->_get_english_month($this->month);
        } else {
            $title = $dateConverter->_get_nepali_month($this->month);
        }

        return $title;
    }

    /**
     *
     */
    public function checkCompleted()
    {
        $model = Self::find($this->id);
        $result = PayrollEmployee::where(['payroll_id' => $model->id, 'status' => 2])->first();
        if($result) {
            return true;
        }

        return false;
    }


    public function createdBy(){
        if($this->created_by_modal && $this->created_by){
            $createdBy=$this->created_by_modal::where('id',$this->created_by)->first();
            if($createdBy){
                return $createdBy->first_name;
            }
        }
        return null;
    }

    public function finalizedBy(){
        if($this->finalized_by_modal && $this->finalized_by){
            $finalizedBy=$this->finalized_by_modal::where('id',$this->finalized_by)->first();
            if($finalizedBy){
                return $finalizedBy->first_name;
            }
        }
        return null;
    }
}
