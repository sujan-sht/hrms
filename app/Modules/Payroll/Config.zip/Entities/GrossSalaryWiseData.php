<?php

namespace App\Modules\Payroll\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class GrossSalaryWiseData extends Model
{
    protected $fillable = [
        'organization_id',
        'level_id',
        'designation_id',
        'employee_id',
        'gross_salary',
        'grade',
        'gross_salary_setup_type'
    ];
}
