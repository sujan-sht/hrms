<?php

namespace App\Modules\Payroll\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class DeductionReferenceSetupDetail extends Model
{
    protected $fillable = [
        'deduction_setup_id',
        'deduction_reference_setups',
        'level_id',
        'designation_id',
        'employee_id'
       
    ];

    public function deductionReferenceSetup(){
        return $this->hasOne(DeductionReferenceSetup::class,'id','deduction_reference_setups');
    }
}
