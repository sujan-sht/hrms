<?php

namespace App\Modules\Payroll\Entities;

use Illuminate\Database\Eloquent\Model;

class PayrollDeduction extends Model
{
    protected $fillable = [
        'payroll_id',
        'payroll_employee_id',
        'deduction_setup_id',
        'value'
    ];

    /**
     * Relation with payroll
     */
    public function payroll()
    {
        return $this->belongsTo(Payroll::class, 'payroll_id');
    }

    /**
     * Relation with payroll employee
     */
    public function payrollEmployee()
    {
        return $this->belongsTo(PayrollEmployee::class, 'payroll_employee_id');
    }

    /**
     * Relation with deduction setup
     */
    public function deductionSetup()
    {
        return $this->belongsTo(DeductionSetup::class, 'deduction_setup_id');
    }
}
