<?php

namespace App\Modules\Payroll\Entities;

use App\Modules\Employee\Entities\Employee;
use Illuminate\Database\Eloquent\Model;

class EmployeeSetup extends Model
{
    protected $fillable = ['employee_id','organization_id','reference','reference_id','status','amount','income_value_setup_id','gross_setup_type'];


    public function employee()
    {
        return $this->belongsTo(Employee::class, 'employee_id', 'id');
    }

    public function deduction()
    {
        return $this->belongsTo(DeductionSetup::class, 'reference_id', 'id');
    }
    public function income()
    {
        return $this->belongsTo(IncomeSetup::class, 'reference_id', 'id');
    }
}
