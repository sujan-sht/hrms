<?php

namespace App\Modules\Payroll\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use App\Modules\Payroll\Entities\IncomeReferenceSetupDetail;
use App\Modules\Payroll\Entities\IncomeReferenceSetUpPercentage;

class IncomeReferenceSetup extends Model
{

    protected $fillable = [
        'income_setup_id',
        'organization_id',
        'method',
        'amount',
        'setting_setup_type'
    ];

    public function incomeReferenceSetupDetail(){
        return $this->hasMany(IncomeReferenceSetupDetail::class,'income_reference_setups','id');
    }

    public function incomeReferenceSetUpPercentage(){
        return $this->hasMany(IncomeReferenceSetUpPercentage::class,'income_reference_setups','id');
    }
    
  
}
