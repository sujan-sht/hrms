<?php

namespace App\Modules\Payroll\Entities;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class PayrollTaxExcludeValue extends Model
{
    
    protected $fillable = ['payroll_id','payroll_employee_id','tax_exclude_setup_id','value'];
    
    public function taxExcludeSetup()
    {
        return $this->belongsTo(TaxExcludeSetup::class, 'tax_exclude_setup_id');
    }
}
