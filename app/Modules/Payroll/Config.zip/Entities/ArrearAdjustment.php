<?php

namespace App\Modules\Payroll\Entities;

use App\Modules\Employee\Entities\Employee;
use App\Modules\Organization\Entities\Organization;
use App\Modules\User\Entities\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class ArrearAdjustment extends Model
{
    protected $fillable = [
        'emp_id',
        'name',
        'organization_id',
        'branch_id',
        'designation_id',
        'year',
        'month',
        'emp_status',
        'arrear_amt',
        'effective_date',
        'nep_effective_date',
        'status',
        'created_by',
        'updated_by'
    ];
    public function organization()
    {
        return $this->belongsTo(Organization::class, 'organization_id');
    }
    public function employee()
    {
        return $this->belongsTo(Employee::class, 'emp_id');
    }
    public function arrearAdjustmentDetail()
    {
        return $this->hasMany(ArrearAdjustmentDetail::class);
    }
    public function userInfo(){
        return $this->belongsTo(User::class,'created_by');
    }
}
