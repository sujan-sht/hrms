{{-- <div class="text-right mb-4 mr-5">
    <a href="{{ route('employeeSetup.showIncomes').'?organization_id=' . $_GET['organization_id'] }}" target="_blank" class="btn btn-success rounded-pill">View Incomes</a>
</div> --}}
<div class="table-responsive">
    <table class="table table-hover">
        <thead>
            <tr class="text-light btn-slate">
                <th>S.N</th>
                <th>Employee Name</th>
                {{-- <th>Gross Salary</th> --}}
                @foreach ($incomeList as $k => $income)
                    <th>{{ $income }}</th>
                @endforeach

            </tr>
        </thead>
        <tbody>
            {{-- @dd($employeeList->toArray()) --}}
            @foreach ($employeeList as $key => $item)
            {{-- {{dd($item)}}; --}}

                <tr>
                    <td>{{ '#' . ++$key }}</td>
                    <td>
                        <div class="media">
                            <div class="mr-3">
                                <a href="#">
                                    <img src="{{ $item->getImage() }}"
                                        class="rounded-circle" width="40" height="40" alt="">
                                </a>
                            </div>
                            <div class="media-body">
                                <div class="media-title font-weight-semibold">
                                    {{ $item->getFullName() }}</div>
                                <span
                                    class="text-muted">{{ $item->official_email }}</span>
                            </div>
                        </div>
                    </td>
                    {{-- @if (count($item->employeeIncomeSetup) > 0) --}}
                        @foreach ($item->employeeIncomeSetup as $i)
                        {{-- @dd($item,$i) --}}
                            <td><input type="number" name="{{ $item['id'] }}[{{ $i['reference_id'] }}]"
                                    value="{{ $i['amount'] }}" class="form-control" placeholder="Enter income"></td>
                        @endforeach
                     {{-- @else --}}
                        {{-- @foreach ($incomeList as $k => $income)
                            <td><input type="number" name="{{ $item->id }}[{{ $k }}]" class="form-control" placeholder="Enter income"></td>
                        @endforeach --}}
                    {{-- @endif --}}
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
<div class="text-right">
    <button type="submit" class="ml-2 mt-2 btn text-white bg-pink btn-labeled btn-labeled-left"><b><i
                class="icon-database-insert"></i></b> Save</button>
</div>
