<div class="table-responsive">
    <table class="table table-hover">
        <thead>
            <tr class="text-light btn-slate">
                <th>S.N</th>
                @foreach($columns as $column)
                    <th>{{$column}}</th>
                @endforeach
                <th>Gross Salary</th>
                {{-- <th>Grade</th> --}}
            </tr>
        </thead>
        <tbody>
            @foreach ($getSetWiseAllowaceSetups as $key => $item)
                <tr>
                    <td>{{ '#' . ++$key }}</td>
                    @foreach($item['columns'] as $indexValue=>$colData)
                            <td>{!! @$colData !!}</td>
                    @endforeach

                    <td><input type="number" name="gross_salary[{{ $item['id'] }}]" value="{{@$item['gross_salary']}}" class="form-control" placeholder="Enter Gross Salary"></td>
                    {{-- <td><input type="number" name="grade[{{ $item['id'] }}]" value="{{@$item['grade']}}" class="form-control" placeholder="Enter Grade"></td> --}}
                </tr>
            @endforeach
        </tbody>
    </table>
</div>
<div class="text-right">
    <button type="submit" class="ml-2 mt-2 btn text-white bg-pink btn-labeled btn-labeled-left"><b><i
                class="icon-database-insert"></i></b> Save</button>
</div>
