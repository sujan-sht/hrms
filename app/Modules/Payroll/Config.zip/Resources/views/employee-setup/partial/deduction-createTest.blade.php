{{-- <div class="text-right mb-4 mr-5">
    <a href="{{ route('employeeSetup.showIncomes').'?organization_id=' . $_GET['organization_id'] }}" target="_blank" class="btn btn-success rounded-pill">View Incomes</a>
</div> --}}
<div class="table-responsive">
    <table class="table table-hover">
        <thead>
            <tr class="text-light btn-slate">
                <th>S.N</th>
                {{-- <th>Gross Salary</th> --}}
                @foreach ($columns as $k => $columnsValue)
                    <th>{{ $columnsValue }}</th>
                @endforeach

                @foreach ($deductionList as $k => $list)
                    <th>{{ $list }}</th>
                @endforeach

            </tr>
        </thead>
        <tbody>
            @foreach($getSetWiseAllowaceSetups as $key=>$item)
            {{-- @dd($item) --}}
                <tr>
                    <td>{{ '#' . ++$key }}</td>
                    @foreach($item['columns'] as $indexValue=>$colData)
                            <td>{!! @$colData !!}</td>
                    @endforeach
                    {{-- @dd($item); --}}
                    @if(isset($item['incomeValues'] ))
                        @foreach($item['incomeValues'] as $incomeSetupId=>$value)
                        {{-- @dd($incomeSetupId) --}}
                        <td><input type="number" name="{{$item['id']}}[{{$incomeSetupId}}]"
                            value="{{$value}}" class="form-control" placeholder="Enter income"></td>
                        @endforeach
                    @endif
                </tr>
            @endforeach
            {{-- @dd($filtersValue) --}}
            <input type="text" name="setupType" value="{{$grossSalarySetupType->gross_salary_type}}" hidden>
            <input type="text" name="organization_id" value="{{@request()->get('organization_id') ?? null}}" hidden>
        </tbody>
    </table>
</div>
<div class="text-right">
    <button type="submit" class="ml-2 mt-2 btn text-white bg-pink btn-labeled btn-labeled-left"><b><i
                class="icon-database-insert"></i></b> Save</button>
</div>
