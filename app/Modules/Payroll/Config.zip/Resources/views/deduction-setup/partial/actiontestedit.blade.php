@inject('income_setups', '\App\Modules\Payroll\Repositories\IncomeSetupRepository')

<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-body">
                <legend class="text-uppercase font-size-sm font-weight-bold">Basic Detail</legend>
                <div class="form-group row">
                    <div class="col-lg-12 mb-3">
                        <div class="row">
                            <label class="col-form-label col-lg-2">Organization:<span class="text-danger">
                                    *</span></label>
                            <div class="col-lg-10 form-group-feedback form-group-feedback-right">
                                <div class="input-group">
                                    {!! Form::select('organization_id', $organizationList, null, [
                                        'placeholder' => 'Select Organization',
                                        'class' => 'form-control select-search organization',
                                    ]) !!}
                                </div>
                                @if ($errors->has('organization_id'))
                                    <div class="error text-danger">{{ $errors->first('organization_id') }}</div>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 mb-3">
                        {{-- {{dd($deductionSetupModel->income_id)}} --}}
                        <div class="row">
                            <label class="col-form-label col-lg-4">Title : <span class="text-danger">*</span></label>
                            <div class="col-lg-8 form-group-feedback form-group-feedback-right">
                                <div class="input-group">
                                    {!! Form::text('title', null, ['placeholder' => 'Enter Title', 'class' => 'form-control']) !!}
                                </div>
                                @if ($errors->has('title'))
                                    <div class="error text-danger">{{ $errors->first('title') }}</div>
                                @endif
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 mb-3">
                        <div class="row">
                            <label class="col-form-label col-lg-3">Short Name : <span
                                    class="text-danger">*</span></label>
                            <div class="col-lg-9 form-group-feedback form-group-feedback-right">
                                <div class="input-group">
                                    @if ($isEdit)
                                        {!! Form::text('short_name', null, ['placeholder' => 'Enter Short Name', 'readonly', 'class' => 'form-control']) !!}
                                    @else
                                        {!! Form::text('short_name', null, ['placeholder' => 'Enter Short Name', 'class' => 'form-control']) !!}
                                    @endif
                                </div>
                                @if ($errors->has('short_name'))
                                    <div class="error text-danger">{{ $errors->first('short_name') }}</div>
                                @endif
                            </div>
                        </div>
                    </div>

                </div>
                <div id="appendDataHtml">
                    @if ($deductionSetupModel->deductionReferenceSetup && count($deductionSetupModel->deductionReferenceSetup) > 0)
                        @foreach ($deductionSetupModel->deductionReferenceSetup as $key => $model)
                            <div class="form-group row mt-4 border border-light rounded pt-3 shadow-sm">
                                <div class="col-lg-6 mb-3">
                                    <div class="row">
                                        <label class="col-form-label col-lg-4">{{ @$filterSetupDatas['filterName'] }}
                                            :</label>
                                        <div class="col-lg-8 form-group-feedback form-group-feedback-right">
                                            <div class="input-group">
                                                {!! Form::select(
                                                    'setup_level_id[' . $key . '][]',
                                                    $filterSetupDatas['filterDatas'],
                                                    $model->deductionReferenceSetupDetail->pluck($setUpWiseField)->toArray(),
                                                    [
                                                        'class' => 'form-control multiselect-select-all-filtering setup_level_id',
                                                        'multiple' => 'multiple',
                                                    ],
                                                ) !!}

                                            </div>
                                            @if ($errors->has('method'))
                                                <div class="error text-danger">{{ $errors->first('method') }}</div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-3">
                                    <div class="row">
                                    </div>
                                </div>

                                <div class="col-lg-6 mb-3">
                                    <div class="row">
                                        <label class="col-form-label col-lg-4">Method :</label>
                                        <div class="col-lg-8 form-group-feedback form-group-feedback-right">
                                            <div class="input-group">
                                                {!! Form::select('method[' . $key . ']', [1 => 'Fixed', 2 => 'Percentage', 3 => 'Manual'], @$model->method, [
                                                    'class' => 'form-control select-search chooseMethod',
                                                    'sectionId' => $key,
                                                ]) !!}
                                            </div>
                                            @if ($errors->has('method'))
                                                <div class="error text-danger">{{ $errors->first('method') }}</div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-3 amountSection{{ $key }}" style="display:none;">
                                    <div class="row">
                                        <label class="col-form-label col-lg-3">Amount :</label>
                                        <div class="col-lg-9 form-group-feedback form-group-feedback-right">
                                            <div class="input-group">
                                                {!! Form::text('amount[' . $key . ']', @$model->amount, [
                                                    'placeholder' => 'e.g. 2000',
                                                    'class' => 'form-control',
                                                ]) !!}
                                            </div>
                                            @if ($errors->has('amount'))
                                                <div class="error text-danger">{{ $errors->first('amount') }}</div>
                                            @endif
                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6 mb-3 percentageSection{{ $key }}" style="display:none;">
                                    @if ($model->method == '2')
                                        @foreach ($model->deductionReferenceSetUpPercentage as $detailData)
                                            <div class="row">
                                                <label class="col-form-label col-lg-3">Percentage :</label>
                                                <div class="col-lg-9 form-group-feedback form-group-feedback-right">
                                                    <div class="row">
                                                        <div class="input-group col-lg-3">
                                                            {!! Form::text('percentage[' . $key . '][]', @$detailData->percentage, [
                                                                'placeholder' => 'e.g. 10.2',
                                                                'class' => 'form-control',
                                                            ]) !!}
                                                        </div>
                                                        @if ($errors->has('percentage'))
                                                            <div class="error text-danger">
                                                                {{ $errors->first('percentage') }}
                                                            </div>
                                                        @endif
                                                        <div class="col-lg-2 col-form-label">
                                                            <span> % of </span>
                                                        </div>

                                                        <div class="input-group col-lg-5 income">
                                                            {!! Form::select('income_id[' . $key . '][]', @$incomeModels ?? [], @$detailData->income_id, [
                                                                'id' => 'incomeId',
                                                                'class' => 'form-control select-search1 income-filter',
                                                            ]) !!}
                                                            {!! Form::hidden('income', $deductionSetupModel->income_id ?? '', [
                                                                'id' => 'income_id',
                                                                'class' => 'form-control select-search1 income-filter',
                                                            ]) !!}
                                                        </div>

                                                        @if ($errors->has('income_id'))
                                                            <div class="error text-danger">
                                                                {{ $errors->first('income_id') }}</div>
                                                        @endif
                                                        <div class="input-group col-lg-2">
                                                            <button type="button"
                                                                class="add_particular btn bg-success-400 btn-icon addMore"
                                                                id="" data-sectionId="{{@$key}}">
                                                                <i class="icon-plus3"></i><b></b>
                                                            </button>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    {{-- @else
                                        <div class="row">
                                            <label class="col-form-label col-lg-3">Percentage :</label>
                                            <div class="col-lg-9 form-group-feedback form-group-feedback-right">
                                                <div class="row">
                                                    <div class="input-group col-lg-3">
                                                        {!! Form::text('percentage[0][]', null, ['placeholder' => 'e.g. 10.2', 'class' => 'form-control']) !!}
                                                    </div>
                                                    @if ($errors->has('percentage'))
                                                        <div class="error text-danger">
                                                            {{ $errors->first('percentage') }}
                                                        </div>
                                                    @endif
                                                    <div class="col-lg-2 col-form-label">
                                                        <span> % of </span>
                                                    </div>

                                                    <div class="input-group col-lg-5 income">
                                                        {!! Form::select('income_id[0][]', [], null, [
                                                            'id' => 'incomeId',
                                                            'class' => 'form-control select-search1 income-filter',
                                                        ]) !!}
                                                        {!! Form::hidden('income', $deductionSetupModel->income_id ?? '', [
                                                            'id' => 'income_id',
                                                            'class' => 'form-control select-search1 income-filter',
                                                        ]) !!}
                                                    </div>

                                                    @if ($errors->has('income_id'))
                                                        <div class="error text-danger">
                                                            {{ $errors->first('income_id') }}</div>
                                                    @endif
                                                    <div class="input-group col-lg-2">
                                                        <button type="button"
                                                            class="add_particular btn bg-success-400 btn-icon addMore"
                                                            id="" data-sectionId="0">
                                                            <i class="icon-plus3"></i><b></b>
                                                        </button>
                                                    </div>
                                                </div>
                                            </div>
                                        </div> --}}
                                    @endif
                                    <div class="form-repeater{{ @$key }}"></div>
                                </div>

                            </div>
                        @endforeach
                    @else
                        <div class="form-group row mt-4 border border-light rounded pt-3 shadow-sm">
                            <div class="col-lg-6 mb-3">
                                <div class="row">
                                    <label class="col-form-label col-lg-4">{{ @$filterSetupDatas['filterName'] }}
                                        :</label>
                                    <div class="col-lg-8 form-group-feedback form-group-feedback-right">
                                        <div class="input-group">
                                            {!! Form::select('setup_level_id[0][]', $filterSetupDatas['filterDatas'], null, [
                                                'class' => 'form-control multiselect-select-all-filtering setup_level_id',
                                                'multiple' => 'multiple',
                                            ]) !!}

                                        </div>
                                        @if ($errors->has('method'))
                                            <div class="error text-danger">{{ $errors->first('method') }}</div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <div class="row">
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3">
                                <div class="row">
                                    <label class="col-form-label col-lg-4">Method :</label>
                                    <div class="col-lg-8 form-group-feedback form-group-feedback-right">
                                        <div class="input-group">
                                            {!! Form::select('method[0]', [1 => 'Fixed', 2 => 'Percentage', 3 => 'Manual'], null, [
                                                'class' => 'form-control select-search chooseMethod',
                                                'sectionId' => 0,
                                            ]) !!}
                                        </div>
                                        @if ($errors->has('method'))
                                            <div class="error text-danger">{{ $errors->first('method') }}</div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3 amountSection0" style="display:none;">
                                <div class="row">
                                    <label class="col-form-label col-lg-3">Amount :</label>
                                    <div class="col-lg-9 form-group-feedback form-group-feedback-right">
                                        <div class="input-group">
                                            {!! Form::text('amount[0]', null, ['placeholder' => 'e.g. 2000', 'class' => 'form-control']) !!}
                                        </div>
                                        @if ($errors->has('amount'))
                                            <div class="error text-danger">{{ $errors->first('amount') }}</div>
                                        @endif
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 mb-3 percentageSection0" style="display:none;">
                                <div class="row">
                                    <label class="col-form-label col-lg-3">Percentage :</label>
                                    <div class="col-lg-9 form-group-feedback form-group-feedback-right">
                                        <div class="row">
                                            <div class="input-group col-lg-3">
                                                {!! Form::text('percentage[0][]', null, ['placeholder' => 'e.g. 10.2', 'class' => 'form-control']) !!}
                                            </div>
                                            @if ($errors->has('percentage'))
                                                <div class="error text-danger">{{ $errors->first('percentage') }}
                                                </div>
                                            @endif
                                            <div class="col-lg-2 col-form-label">
                                                <span> % of </span>
                                            </div>
                                            <div class="input-group col-lg-5 income">
                                                {!! Form::select('income_id[0][]', [],@$incomeModels ?? null, [
                                                    'id' => 'incomeId',
                                                    'class' => 'form-control select-search1 income-filter',
                                                ]) !!}
                                                {!! Form::hidden('income', $deductionSetupModel->income_id ?? '', [
                                                    'id' => 'income_id',
                                                    'class' => 'form-control select-search1 income-filter',
                                                ]) !!}
                                            </div>

                                            @if ($errors->has('income_id'))
                                                <div class="error text-danger">{{ $errors->first('income_id') }}</div>
                                            @endif
                                            <div class="input-group col-lg-2">
                                                <button type="button"
                                                    class="add_particular btn bg-success-400 btn-icon addMore"
                                                    id="" data-sectionId="0">
                                                    <i class="icon-plus3"></i><b></b>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="form-repeater0"></div>
                            </div>

                        </div>
                    @endif

                </div>

                <div class="form-group row" style="position: relative">
                    <p class="text-danger" id="errorPopup"></p>
                    <a href="javascript:;" class="btn btn-sm btn-danger float:right" id="addSetupData"
                        style="position: absolute;right: 50%;bottom: -11px;">Add More</a>
                </div>

                <div class="col-lg-12 mb-3">
                    <div class="row">
                        <label class="col-form-label col-lg-2">Description:</label>
                        <div class="col-lg-10 form-group-feedback form-group-feedback-right">
                            <div class="input-group">
                                {!! Form::textarea('description', null, [
                                    'placeholder' => 'Write here..',
                                    'class' => 'form-control basicTinymce1',
                                    'id' => 'editor-full',
                                ]) !!}
                            </div>

                            @if ($errors->has('description'))
                                <div class="error text-danger">{{ $errors->first('description') }}</div>
                            @endif
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card">
            <div class="card-body">
                <legend class="text-uppercase font-size-sm font-weight-bold">Setting Detail</legend>
                <div class="row">
                    <div class="col-lg-12 mb-3">
                        <div class="row">
                            <label class="col-form-label col-lg-8">Monthly Deduction :</label>
                            <div class="col-lg-4 form-group-feedback form-group-feedback-right">
                                <div class="input-group">
                                    {!! Form::select('monthly_deduction', [10 => 'No', 11 => 'Yes'], null, [
                                        'class' => 'form-control select-search',
                                    ]) !!}
                                </div>
                                @if ($errors->has('monthly_deduction'))
                                    <div class="error text-danger">{{ $errors->first('monthly_deduction') }}</div>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="row">
                            <label class="col-form-label col-lg-8">Order : <span class="text-danger">*</span></label>
                            <div class="col-lg-4 form-group-feedback form-group-feedback-right">
                                <div class="input-group">
                                    {!! Form::text('order', null, ['placeholder' => 'Enter Order', 'class' => 'form-control']) !!}
                                </div>
                                @if ($errors->has('order'))
                                    <div class="error text-danger">{{ $errors->first('order') }}</div>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 mb-3">
                        <div class="row">
                            <label class="col-form-label col-lg-8">Status :</label>
                            <div class="col-lg-4 form-group-feedback form-group-feedback-right">
                                <div class="input-group">
                                    {!! Form::select('status', [11 => 'Active', 10 => 'Inactive'], null, ['class' => 'form-control select-search']) !!}
                                </div>
                                @if ($errors->has('status'))
                                    <div class="error text-danger">{{ $errors->first('status') }}</div>
                                @endif
                            </div>
                        </div>
                    </div>
                    <!-- <div class="col-lg-12 mb-3">
                        <div class="row">
                            <label class="col-form-label col-lg-3">Tax Deduction :</label>
                            <div class="col-lg-9 form-group-feedback form-group-feedback-right">
                                <div class="input-group">
                                    {!! Form::select('tax_deduction', [10 => 'No', 11 => 'Yes'], null, ['class' => 'form-control select-search']) !!}
                                </div>
                @if ($errors->has('taxable_status'))
<div class="error text-danger">{{ $errors->first('taxable_status') }}</div>
@endif
                            </div>
                        </div>
                    </div> -->

                    <div class="col-lg-12" style="padding: 145px;"></div>

                </div>
            </div>
        </div>
    </div>
</div>
{{-- </div> --}}

<div class="text-center">
    <button type="submit" class="ml-2 btn btn-success btn-labeled btn-labeled-left"><b><i
                class="icon-database-insert"></i></b>{{ $btnType }}</button>
</div>

@section('script')
    <script src="{{ asset('admin/validation/deductionSetup.js') }}"></script>

    <script src="{{ asset('admin/global/js/plugins/forms/styling/uniform.min.js') }}"></script>
    <script src="{{ asset('admin/global/js/demo_pages/form_inputs.js') }}"></script>
    <script src="{{ asset('admin/global/js/plugins/forms/selects/select2.min.js') }}"></script>
    <script src="{{ asset('admin/global/js/demo_pages/form_select2.js') }}"></script>
    <script src="{{ asset('admin/global/js/plugins/editors/ckeditor/ckeditor.js') }}"></script>
    <script src="{{ asset('admin/global/js/demo_pages/editor_ckeditor_default.js') }}"></script>
    <script src="{{ asset('admin/global/js/demo_pages/form_multiselect.js') }}"></script>
    <script src="{{ asset('admin/global/js/plugins/forms/selects/bootstrap_multiselect.js') }}"></script>
    {{-- <script src="https://cdn.tiny.cloud/1/cjrqkjizx7e1ld0p8kcygaj4cvzc6drni6o4xl298c5hl9l1/tinymce/6/tinymce.min.js"
        referrerpolicy="origin"></script> --}}
    <script>
        var incomeModelData=@json($allIncomeModels) ?? null;
        $(document).ready(function() {
            var countValue = 0;
            const updateMethod = () => {
                $('.chooseMethod').on('change', function() {
                    let method = $(this).val();
                    let sectionId = $(this).attr('sectionId');
                    if (method == 2) {
                        $(`.amountSection${sectionId}`).hide();
                        $(`.percentageSection${sectionId}`).show();
                    } else {
                        $(`.amountSection${sectionId}`).show();
                        $(`.percentageSection${sectionId}`).hide();
                    }
                });
            };
            updateMethod();
            $('.chooseMethod').trigger('change');

            const generateHtml = (sectionId) => {
                var incomeModelDataText='';
                var organizationId=$('.organization').val();
                if(incomeModelData && organizationId){
                    incomeModelDataText=`<select id="incomeId" name="income_id[${sectionId}][]" class= "form-control select-search1 income-filter">`;
                    $.each(incomeModelData,function(item,value){
                        if(organizationId==item){
                            $.each(value,function(index,data){
                                incomeModelDataText+=`<option value="${data.id}">${data.title}</option>`;
                            });
                        }
                    });
                    incomeModelDataText+='</select>';
                }else{
                    incomeModelDataText+=`{!! Form::select('income_id[${sectionId}][]', [], null, [
                                                    'id' => 'incomeId',
                                                    'class' => 'form-control select-search1 income-filter',
                                                ]) !!}`;
                }
                return ` <div class="row parent mt-2">
                                    <label class="col-form-label col-lg-3">Percentage :</label>
                                    <div class="col-lg-9 form-group-feedback form-group-feedback-right">
                                        <div class="row">
                                            <div class="input-group col-lg-3">
                                                {!! Form::text('percentage[${sectionId}][]', null, ['placeholder' => 'e.g. 10.2', 'class' => 'form-control']) !!}
                                            </div>
                                            @if ($errors->has('percentage'))
                                                <div class="error text-danger">{{ $errors->first('percentage') }}
                                                </div>
                                            @endif
                                            <div class="col-lg-2 col-form-label">
                                                <span> % of </span>
                                            </div>
                                            <div class="input-group col-lg-5 income">
                                               ${incomeModelDataText}
                                                {!! Form::hidden('income', $deductionSetupModel->income_id ?? '', [
                                                    'id' => 'income_id',
                                                    'class' => 'form-control select-search1 income-filter',
                                                ]) !!}
                                            </div>

                                            @if ($errors->has('income_id'))
                                                <div class="error text-danger">{{ $errors->first('income_id') }}</div>
                                            @endif
                                            <div class="input-group col-lg-2">
                                                <button type="button" class="remove btn bg-success-400 btn-icon">
                                                    <i class="icon-minus-circle2"></i><b></b>
                                                </button>
                                            </div>
                                        </div>
                                    </div>
                                </div>`;
            }
            
            const addMoreField = () => {
                $('.addMore').on('click', function() {
                    let sectionId = $(this).attr('data-sectionId');
                    var html = generateHtml(sectionId);
                    $(`.form-repeater${sectionId}`).append(html);
                });
            }
            addMoreField();
            $(document).on('click', '.remove', function() {
                $(this).closest('.parent').remove();
                $(this).closest('.parent').html('');
            });
            var selectedIds = [];
            var currentSelectedIds = [];
            var itemsIds = @json($itemsIds);
            const updateSelectedid = () => {
                $('.setup_level_id').on('change', function() {
                    var levelIdValue = document.getElementsByClassName('setup_level_id');
                    selectedIds = [];
                    currentSelectedIds = [];
                    $('.setup_level_id').find('option:selected').each(function() {
                        selectedIds.push($(this).val());
                    });
                    $(this).find('option:selected').each(function() {
                        currentSelectedIds.push($(this).val());
                    });
                    var allItemsSelected = itemsIds.every(function(itemId) {
                        return selectedIds.includes(itemId.toString());
                    });
                    if (allItemsSelected) {
                        $('#addSetupData').hide();
                    } else {
                        $('#addSetupData').show();
                    }
                });
            }
            updateSelectedid();
            $('#addSetupData').on('click', function() {
                $('#errorPopup').text('');
                countValue += 1;
                $.ajax({
                    url: "{{ route('getSetupAjaxDataDeduction') }}",
                    type: "get",
                    data: {
                        seletedids: selectedIds,
                        checkIds: currentSelectedIds,
                        countValue: countValue
                    },
                    success: function(response) {
                        if (response.error) {
                            $('#errorPopup').text(response.msg);
                            countValue -= 1;
                            return false;
                        }
                        $('#appendDataHtml').append(response.view);
                        $('.multiselect-select-all-filtering').multiselect({
                            includeSelectAllOption: true,
                            enableFiltering: true,
                            enableCaseInsensitiveFiltering: true
                        });
                        currentSelectedIds = [];
                        updateSelectedid();
                        updateMethod();
                        $('.addMore').off('click');
                        addMoreField();
                    }
                });
            });
            $('.organization').on('change', function() {
                getIncomesByOrganization();
            });



        });


        function getIncomesByOrganization() {
            var organizationId = $('.organization').val();
            var incomeId = $('#income_id').val();
            $.ajax({
                type: 'GET',
                url: '/admin/deduction-setup/get-incomes',
                data: {
                    organization_id: organizationId
                },
                success: function(data) {
                    var list = JSON.parse(data);
                    var options = '';
                    options += "<option value=''>Select Incomes</option>";
                    $.each(list, function(id, value) {
                        if (id == incomeId) {
                            options += "<option value='" + id + "' selected>" + value +
                                "</option>";
                        } else {
                            options += "<option value='" + id + "'>" + value +
                                "</option>";
                        }

                    });

                    $('.income-filter').html(options);
                }
            });
        }

        
    </script>
@endSection
