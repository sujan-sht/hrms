<div class="form-group row mt-4 border border-light rounded pt-3 shadow-sm">
    <div class="col-lg-6 mb-3">
        <div class="row">
            <label class="col-form-label col-lg-4">{{ @$filterSetupDatas['filterName'] }} :</label>
            <div class="col-lg-8 form-group-feedback form-group-feedback-right">
                <div class="input-group">
                    {!! Form::select('setup_level_id['.@$countValue.'][]', $filterSetupDatas['filterDatas'], null, [
                        'class' => 'form-control multiselect-select-all-filtering setup_level_id',
                        'multiple' => 'multiple',
                    ]) !!}

                </div>
                @if ($errors->has('method'))
                    <div class="error text-danger">{{ $errors->first('method') }}</div>
                @endif
            </div>
        </div>
    </div>
    <div class="col-lg-6 mb-3">
        <div class="row">
        </div>
    </div>

    <div class="col-lg-6 mb-3">
        <div class="row">
            <label class="col-form-label col-lg-4">Method :</label>
            <div class="col-lg-8 form-group-feedback form-group-feedback-right">
                <div class="input-group">
                    {!! Form::select('method['.@$countValue.']', [1 => 'Fixed', 2 => 'Percentage', 3 => 'Manual'], null, [
                        'class' => 'form-control select-search chooseMethod',
                        'sectionId' => @$countValue,
                    ]) !!}
                </div>
                @if ($errors->has('method'))
                    <div class="error text-danger">{{ $errors->first('method') }}</div>
                @endif
            </div>
        </div>
    </div>

    <div class="col-lg-6 mb-3 amountSection{{ @$countValue }}" style="">
        <div class="row">
            <label class="col-form-label col-lg-3">Amount :</label>
            <div class="col-lg-9 form-group-feedback form-group-feedback-right">
                <div class="input-group">
                    {!! Form::text('amount['.@$countValue.']', null, ['placeholder' => 'e.g. 2000', 'class' => 'form-control']) !!}
                </div>
                @if ($errors->has('amount'))
                    <div class="error text-danger">{{ $errors->first('amount') }}</div>
                @endif
            </div>
        </div>
    </div>
    <div class="col-lg-6 mb-3 percentageSection{{ @$countValue }}" style="display:none;">
        <div class="row">
            <label class="col-form-label col-lg-3">Percentage :</label>
            <div class="col-lg-9 form-group-feedback form-group-feedback-right">
                <div class="row">
                    <div class="input-group col-lg-3">
                        {!! Form::text('percentage['.@$countValue.'][]', null, ['placeholder' => 'e.g. 10.2', 'class' => 'form-control']) !!}
                    </div>
                    @if ($errors->has('percentage'))
                        <div class="error text-danger">{{ $errors->first('percentage') }}</div>
                    @endif
                    <div class="col-lg-2 col-form-label">
                        <span> % of </span>
                    </div>
                    {{-- <div class="input-group col-lg-5">
                        {!! Form::select('salary_type['.@$countValue.'][]', $salaryType, null, [
                            'class' => 'form-control select-search',
                        ]) !!}
                    </div>

                    @if ($errors->has('salary_type'))
                        <div class="error text-danger">{{ $errors->first('salary_type') }}</div>
                    @endif --}}

                    <div class="input-group col-lg-5 income">
                        {!! Form::select('income_id['.@$countValue.'][]', [], null, [
                            'id' => 'incomeId',
                            'class' => 'form-control select-search1 income-filter',
                        ]) !!}
                        {!! Form::hidden('income', $deductionSetupModel->income_id ?? '', [
                            'id' => 'income_id',
                            'class' => 'form-control select-search1 income-filter',
                        ]) !!}
                        {{-- {!! Form::select('income_id', $incomeList, null, ['class' => 'form-control select-search']) !!} --}}
                    </div>


                    <div class="input-group col-lg-2">
                        <button type="button" class="add_particular btn bg-success-400 btn-icon addMore" id=""
                            data-sectionId="{{ @$countValue }}">
                            <i class="icon-plus3"></i><b></b>
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <div class="form-repeater{{ @$countValue }}"></div>
        {{-- <div id="repeatForm" style="display:none;">
            <div class="row parent mt-2">
                <label class="col-form-label col-lg-3">Percentage :</label>
                <div class="col-lg-9 form-group-feedback form-group-feedback-right">
                    <div class="row">
                        <div class="input-group col-lg-3">
                            {!! Form::text('percentage['.@$countValue.'][]', null, ['placeholder' => 'e.g. 10.2', 'class' => 'form-control']) !!}
                        </div>
                        @if ($errors->has('percentage'))
                            <div class="error text-danger">{{ $errors->first('percentage') }}</div>
                        @endif
                        <div class="col-lg-2 col-form-label">
                            <span> % of </span>
                        </div>
                        <div class="input-group col-lg-5">
                            {!! Form::select('salary_type['.@$countValue.'][]', $salaryType, null, [
                                'class' => 'form-control salary',
                            ]) !!}
                        </div>

                        @if ($errors->has('salary_type'))
                            <div class="error text-danger">{{ $errors->first('salary_type') }}</div>
                        @endif
                        <div class="input-group col-lg-2">
                            <button type="button" class="add_particular btn bg-success-400 btn-icon remove">
                                <i class="icon-minus-circle2"></i><b></b>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </div> --}}
    </div>
</div>
