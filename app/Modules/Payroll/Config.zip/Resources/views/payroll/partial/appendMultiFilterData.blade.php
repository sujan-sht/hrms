{!! Form::select(@$field_name.'[]', @$values, null, [
    'id' => @$fieldId,
    'class' => 'form-control '.@$field_name.' multiselect-select-all-filtering',
    'multiple' => 'multiple',
]) !!}
