@extends('admin::layout')
@section('title') Yearly Pay Slip @endSection
@section('breadcrum')
<a href="{{route('payroll.index')}}" class="breadcrumb-item">Payroll</a>
<a class="breadcrumb-item active">Yearly PaySlip</a>
@stop

@section('content')

@include('payroll::yearly-pay-slip.partial.advance_filter')
@endSection
